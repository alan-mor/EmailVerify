# app.py
import os
from flask import Flask
from dotenv import load_dotenv
from extensions import db, login_manager, celery

load_dotenv()


def create_app():
    app = Flask(__name__, static_folder='static', template_folder='templates')

    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'change-me')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///ev.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024
    app.config['UPLOAD_FOLDER']    = os.getenv('UPLOAD_FOLDER', 'uploads')
    app.config['RESULTS_FOLDER']   = os.getenv('RESULTS_FOLDER', 'results')
    app.config['BLACKLIST_FOLDER'] = os.getenv('BLACKLIST_FOLDER', 'blacklists')

    redis_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    app.config['CELERY_BROKER_URL']    = redis_url
    app.config['CELERY_RESULT_BACKEND'] = redis_url

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    celery.conf.update(
        broker_url=redis_url,
        result_backend=redis_url,
        task_serializer='json',
        result_serializer='json',
        accept_content=['json'],
        timezone='America/Merida',
        enable_utc=False,
    )

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)
    celery.Task = ContextTask

    from routes.auth      import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.verify    import verify_bp
    from routes.admin     import admin_bp
    from routes.api       import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(verify_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(api_bp, url_prefix='/api')

    return app


app = create_app()

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)
