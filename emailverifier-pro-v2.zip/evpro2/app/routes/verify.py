# routes/verify.py
# tasks se importa LAZY (dentro de función) para evitar import circular
import os
import uuid
from datetime import datetime
import pytz

from flask import (Blueprint, render_template, redirect, url_for,
                   request, flash, current_app)
from flask_login import login_required, current_user

from extensions import db
from models import VerificationJob, BlacklistEmail, BlacklistDomain

verify_bp = Blueprint('verify', __name__)
MX_TZ = pytz.timezone('America/Merida')
ALLOWED = {'txt', 'csv', 'xlsx', 'xls'}


def _allowed(fn):
    return '.' in fn and fn.rsplit('.', 1)[1].lower() in ALLOWED


@verify_bp.route('/verify', methods=['GET', 'POST'])
@login_required
def new_verification():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        notify_email = request.form.get('notify_email', '').strip()

        if not name:
            flash('Escribe un nombre para la verificación', 'error')
            return redirect(url_for('verify.new_verification'))

        if 'file' not in request.files or request.files['file'].filename == '':
            flash('Selecciona un archivo para verificar', 'error')
            return redirect(url_for('verify.new_verification'))

        f = request.files['file']
        if not _allowed(f.filename):
            flash('Formato no soportado. Usa TXT, CSV o XLSX', 'error')
            return redirect(url_for('verify.new_verification'))

        upload_folder = current_app.config['UPLOAD_FOLDER']
        os.makedirs(upload_folder, exist_ok=True)
        ext = f.filename.rsplit('.', 1)[1].lower()
        filename = f'{uuid.uuid4().hex}.{ext}'
        filepath = os.path.join(upload_folder, filename)
        f.save(filepath)

        job = VerificationJob(
            user_id=current_user.id,
            name=name,
            status='pending',
            input_file=filepath,
            notify_email=notify_email or None,
            created_at=datetime.now(MX_TZ).replace(tzinfo=None),
        )
        db.session.add(job)
        db.session.commit()

        # LAZY IMPORT — evita circular import al cargar el módulo
        from tasks import run_verification
        task = run_verification.delay(job.id)
        job.celery_task_id = task.id
        job.add_log('⏳ Tarea enviada al worker, iniciando...')
        db.session.commit()

        flash(f'✅ Verificación "{name}" iniciada. Puedes cerrar el navegador.', 'success')
        return redirect(url_for('dashboard.job_detail', job_id=job.id))

    return render_template('new_verification.html')


@verify_bp.route('/blacklist', methods=['GET', 'POST'])
@login_required
def blacklist():
    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'add_email':
            email = request.form.get('email', '').strip().lower()
            reason = request.form.get('reason', '').strip()
            if '@' in email and not BlacklistEmail.query.filter_by(email=email, user_id=current_user.id).first():
                db.session.add(BlacklistEmail(email=email, reason=reason,
                               user_id=current_user.id, added_by=current_user.id))
                db.session.commit()
                flash(f'{email} agregado a lista negra', 'success')

        elif action == 'add_domain':
            domain = request.form.get('domain', '').strip().lower()
            reason = request.form.get('reason', '').strip()
            if '.' in domain and not BlacklistDomain.query.filter_by(domain=domain, user_id=current_user.id).first():
                db.session.add(BlacklistDomain(domain=domain, reason=reason,
                               user_id=current_user.id, added_by=current_user.id))
                db.session.commit()
                flash(f'{domain} agregado', 'success')

        elif action == 'import_file':
            file = request.files.get('blacklist_file')
            if file:
                added = 0
                for line in file.read().decode('utf-8', errors='ignore').splitlines():
                    item = line.strip().lower()
                    if not item:
                        continue
                    if '@' in item:
                        if not BlacklistEmail.query.filter_by(email=item, user_id=current_user.id).first():
                            db.session.add(BlacklistEmail(email=item, user_id=current_user.id, added_by=current_user.id))
                            added += 1
                    elif '.' in item:
                        if not BlacklistDomain.query.filter_by(domain=item, user_id=current_user.id).first():
                            db.session.add(BlacklistDomain(domain=item, user_id=current_user.id, added_by=current_user.id))
                            added += 1
                db.session.commit()
                flash(f'{added} entradas importadas', 'success')

        elif action == 'delete_email':
            b = BlacklistEmail.query.get(request.form.get('id'))
            if b and (b.user_id == current_user.id or current_user.is_admin):
                db.session.delete(b); db.session.commit()

        elif action == 'delete_domain':
            b = BlacklistDomain.query.get(request.form.get('id'))
            if b and (b.user_id == current_user.id or current_user.is_admin):
                db.session.delete(b); db.session.commit()

        return redirect(url_for('verify.blacklist'))

    return render_template('blacklist.html',
                           emails=BlacklistEmail.query.filter_by(user_id=current_user.id).all(),
                           domains=BlacklistDomain.query.filter_by(user_id=current_user.id).all())
