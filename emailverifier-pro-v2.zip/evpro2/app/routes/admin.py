# routes/admin.py
from functools import wraps
from flask import Blueprint, render_template, redirect, url_for, request, flash, abort
from flask_login import login_required, current_user
from extensions import db
from models import User, AppConfig, VerificationJob

admin_bp = Blueprint('admin', __name__)


def admin_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*a, **kw)
    return dec


@admin_bp.route('/admin')
@login_required
@admin_required
def index():
    return redirect(url_for('admin.users'))


@admin_bp.route('/admin/users', methods=['GET', 'POST'])
@login_required
@admin_required
def users():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'create':
            uname = request.form.get('username', '').strip()
            pwd   = request.form.get('password', '').strip()
            email = request.form.get('email', '').strip() or None
            is_admin = request.form.get('is_admin') == 'on'
            if not uname or not pwd:
                flash('Usuario y contraseña requeridos', 'error')
            elif User.query.filter_by(username=uname).first():
                flash('Ese usuario ya existe', 'error')
            else:
                u = User(username=uname, email=email, is_admin=is_admin)
                u.set_password(pwd)
                db.session.add(u); db.session.commit()
                flash(f'Usuario {uname} creado', 'success')
        elif action == 'toggle_active':
            u = User.query.get(request.form.get('user_id'))
            if u and u.id != current_user.id:
                u.is_active = not u.is_active
                db.session.commit()
                flash(f'Usuario {u.username} {"activado" if u.is_active else "desactivado"}', 'success')
        elif action == 'change_password':
            u = User.query.get(request.form.get('user_id'))
            pwd = request.form.get('new_password', '').strip()
            if u and pwd:
                u.set_password(pwd); db.session.commit()
                flash(f'Contraseña de {u.username} actualizada', 'success')
        elif action == 'delete':
            u = User.query.get(request.form.get('user_id'))
            if u and u.id != current_user.id:
                db.session.delete(u); db.session.commit()
                flash('Usuario eliminado', 'success')
        return redirect(url_for('admin.users'))
    return render_template('admin/users.html', users=User.query.all())


@admin_bp.route('/admin/config', methods=['GET', 'POST'])
@login_required
@admin_required
def config():
    keys = ['smtp_host','smtp_port','smtp_user','smtp_pass','smtp_from',
            'smtp_ssl','enable_smtp_verify','dns_retries','smtp_timeout',
            'max_workers','site_name','site_url']
    if request.method == 'POST':
        for k in keys:
            AppConfig.set(k, request.form.get(k, '').strip())
        flash('Configuración guardada', 'success')
        return redirect(url_for('admin.config'))
    cfg = {k: AppConfig.get(k, '') for k in keys}
    defaults = {'smtp_port':'587','smtp_ssl':'tls','enable_smtp_verify':'true',
                'dns_retries':'3','smtp_timeout':'10','max_workers':'10',
                'site_name':'EmailVerifier Pro'}
    for k, v in defaults.items():
        if not cfg.get(k):
            cfg[k] = v
    return render_template('admin/config.html', cfg=cfg)


@admin_bp.route('/admin/all-jobs')
@login_required
@admin_required
def all_jobs():
    jobs = VerificationJob.query.order_by(VerificationJob.created_at.desc()).all()
    users = {u.id: u.username for u in User.query.all()}
    return render_template('admin/all_jobs.html', jobs=jobs, users=users)
