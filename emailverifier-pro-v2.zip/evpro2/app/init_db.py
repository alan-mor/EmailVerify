# init_db.py
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app
from extensions import db
from models import User, AppConfig


def init():
    with app.app_context():
        db.create_all()
        print('✅ Tablas creadas')

        if not User.query.filter_by(username='alanmor').first():
            admin = User(username='alanmor', is_admin=True, is_active=True)
            admin.password_hash = (
                '567ee3dadc9d4b1ea71ea34885129cd890fdf0dc6f722beee378481'
                'fb0352166fa571013c89605403f1316a60331dbd1b2b03e9fd37f5b'
                'e4490d885d43839a96'
            )
            db.session.add(admin)
            db.session.commit()
            print('✅ Usuario admin creado')
        else:
            print('ℹ️  Admin ya existe')

        defaults = {
            'smtp_host':'','smtp_port':'587','smtp_user':'',
            'smtp_pass':'','smtp_from':'','smtp_ssl':'tls',
            'enable_smtp_verify':'true','dns_retries':'3',
            'smtp_timeout':'10','max_workers':'10',
            'site_name':'EmailVerifier Pro','site_url':'',
        }
        for k, v in defaults.items():
            if AppConfig.get(k) is None:
                AppConfig.set(k, v)

        print('✅ Configuración inicial lista')
        print('🚀 Base de datos lista')


if __name__ == '__main__':
    init()
