# verifier.py — Motor de verificación avanzado v2
import re
import socket
import smtplib
import time
import logging
from typing import Dict, List, Tuple, Optional

import dns.resolver
import dns.exception

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────
# LISTAS DE DETECCIÓN
# ──────────────────────────────────────────────────────────────

ROLE_ACCOUNTS = {
    'noreply','no-reply','no_reply','donotreply','do-not-reply','do_not_reply',
    'postmaster','mailer-daemon','mailer_daemon','mailerdaemon',
    'antispam','anti-spam','anti_spam','spam','spamtrap','spam-trap',
    'abuse','security','hostmaster','webmaster','www','uucp','ftp',
    'root','operator','daemon','bin','sys','nobody','null','devnull',
    'blackhole','bounce','bounces','ndr','return','returns',
    'unsubscribe','subscribe','newsletter','newsletters','notification',
    'notifications','alerts','alert','info','information','help',
    'helpdesk','support','admin','administrator','sysadmin','contact',
    'sales','marketing','billing','invoices','invoice','accounts',
    'account','service','services','team','office','staff','mail',
    'email','mailbox','inbox','test','testing','demo','example','sample',
    'anonymous','anon','delete','deleted','removed','invalid','unknown',
    'undisclosed','recipient','recipients','feedback','reply','replies',
    'autoresponder','auto-responder','auto_responder','vacation',
    'out-of-office','outofoffice','ops','operations','legal','hr',
    'humanresources','it','tech','techsupport','register','registration',
    'confirm','confirmation','verify','verification','activate',
    'activation','password','reset','welcome','system','automated',
    'automatic','robot','bot','crawler','spider','network','monitoring',
    'monitor','report','reports','analytics','stats','statistics',
    'press','media','pr','publicrelations','partnerships','partner',
    'vendor','suppliers','supplier','procurement','orders','order',
    'shipping','delivery','logistics','warehouse','store','shop',
    'payment','payments','finance','financial','tax','vat','compliance',
    'privacy','gdpr','dpo','catch-all','catchall','dns','smtp','imap',
    'pop3','fax','calendar','scheduler','cron','jobs','job','careers',
    'career','hiring','recruitment','recruiter','sales-team',
    'customerservice','customer-service','cs','helpdesk','servicedesk',
}

ROLE_PREFIXES = [
    'noreply','no-reply','donotreply','bounce','postmaster',
    'mailer','abuse','newsletter','unsubscribe','info@',
    'admin','support','help','contact','sales','marketing',
    'notify','notification','alert','automated','auto-',
    'robot','bot-','crawler','spider','system-',
]

ANTISPAM_MX = [
    'ik2','spamexperts','spamhero','spamsoap','antispamcloud',
    'mxlogic','postini','messagelabs','symanteccloud','proofpoint',
    'pphosted','barracuda','cudamail','reflexion','appriver',
    'exclaimer','mimecast','hornetsecurity','mailprotect',
    'mailscanner','spamfilter','antispam','spam-filter',
    'maildefense','mailcleaner','mailwasher','mailprotector',
    'cleanmx','mailpure','spamblocker','mailguard','mailsecurity',
    'mailgate','mailarmor','spamtitan','securence','zixmail',
    'zixcorp','trustifi','avanan','abnormalsecurity','ironscales',
    'cofense','agari','vade','vadesecure','mailroute','mailhop',
    'returnpath','validity','spamcop','cloudmark','senderscore',
    'mailchannels','halon','rspamd','spamassassin','amavis',
]

PARKED_MX = [
    r'sedoparking', r'parkingcrew', r'bodis', r'above\.com',
    r'hugedomains', r'parking', r'sinkhole', r'afternic',
    r'dan\.com', r'sedo\.com', r'domaincontrol\.com',
    r'registrar-servers\.com', r'namebrightdns\.com',
    r'parklogic\.com', r'domainsponsor\.com',
]

DISPOSABLE = {
    'mailinator.com','guerrillamail.com','tempmail.com','yopmail.com',
    'sharklasers.com','guerrillamail.info','guerrillamail.biz',
    'guerrillamail.de','guerrillamail.net','guerrillamail.org',
    'spam4.me','trashmail.com','trashmail.me','trashmail.net',
    'trashmail.at','trashmail.io','trashmail.xyz','dispostable.com',
    'mailnull.com','spamgourmet.com','10minutemail.com',
    '10minutemail.net','10minutemail.org','tempinbox.com',
    'tempr.email','discard.email','maildrop.cc','mailnesia.com',
    'getnada.com','wegwerfmail.de','tempmail.ninja','tempmail.plus',
    'fakemail.net','emailondeck.com','mailtemp.info','throwam.com',
    'mailin8r.com','dodgit.com','hmamail.com','spamstack.net',
    'mohmal.com','safetymail.info','mailexpire.com','jetable.fr.nf',
    'mailinator2.com','trashdevil.com','spamevader.net',
    'crazymailing.com','nervmich.net','spamfree24.org',
    'spamfree24.de','spamfree24.eu','spamfree24.info',
    'spamfree24.net','spamfree24.com','inoutmail.eu',
    'tempinbox.de','spamhere.eu','mailscrap.com','mailrock.biz',
    'getairmail.com','filzmail.com','incognitomail.com',
    'throwam.com','anonaddy.com','simplelogin.io',
    'spamgob.com','spamcorptastic.com','spaml.com',
    'spam.la','deadaddress.com','trashmail.me','throwam.com',
    'mailnew.com','trashmail.com','yopmail.fr','cool.fr.nf',
    'jetable.fr.nf','nospam.ze.tc','nomail.xl.cx',
    'mega.zik.dj','speed.1s.fr','courriel.fr.nf',
    'moncourrier.fr.nf','monemail.fr.nf','monmail.fr.nf',
}

FREEMAIL = {
    'gmail.com','yahoo.com','hotmail.com','outlook.com','live.com',
    'msn.com','icloud.com','me.com','mac.com','aol.com',
    'yahoo.es','yahoo.com.mx','yahoo.co.uk','yahoo.fr',
    'yahoo.de','yahoo.it','yahoo.com.ar','yahoo.com.br',
    'hotmail.es','hotmail.com.mx','hotmail.co.uk','hotmail.fr',
    'hotmail.de','hotmail.it','hotmail.com.ar','hotmail.com.br',
    'live.com.mx','live.es','live.co.uk','live.fr',
    'outlook.es','outlook.com.mx','protonmail.com','proton.me',
    'tutanota.com','tutamail.com','zoho.com','gmx.com',
    'gmx.net','gmx.de','web.de','t-online.de','libero.it',
    'virgilio.it','tin.it','alice.it','terra.com.br',
    'uol.com.br','bol.com.br','ig.com.br',
}

# TLDs de alto riesgo
HIGH_RISK_TLDS = {
    'xyz','top','click','work','gq','cf','ga','ml','tk',
    'loan','win','racing','download','stream','faith','bid',
    'review','trade','accountant','cricket','science','party',
    'date','men','webcam','kim','country','pw','space',
}

# Regex de sintaxis
_EMAIL_RE = re.compile(
    r'^[a-zA-Z0-9][a-zA-Z0-9._%+\-]{0,63}'
    r'@'
    r'(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)'
    r'+[a-zA-Z]{2,}$'
)


# ──────────────────────────────────────────────────────────────
# CHECK FUNCTIONS
# ──────────────────────────────────────────────────────────────

def check_syntax(email: str) -> Tuple[bool, str]:
    if not email or not isinstance(email, str):
        return False, 'Email vacío o nulo'
    e = email.strip().lower()
    if len(e) > 320:
        return False, 'Email demasiado largo (>320 chars)'
    if len(e) < 6:
        return False, 'Email demasiado corto'
    cnt = e.count('@')
    if cnt == 0:
        return False, 'Falta símbolo @'
    if cnt > 1:
        return False, f'Múltiples @ ({cnt} encontrados)'
    local, domain = e.rsplit('@', 1)
    if not local:
        return False, 'Parte local vacía'
    if len(local) > 64:
        return False, 'Parte local >64 chars'
    if '..' in e:
        return False, 'Doble punto detectado (..)'
    if local.startswith('.') or local.endswith('.'):
        return False, 'Parte local no puede empezar/terminar con punto'
    if domain.startswith('-') or domain.endswith('-'):
        return False, 'Dominio no puede empezar/terminar con guion'
    if '.' not in domain:
        return False, 'Dominio sin TLD'
    # Caracteres inválidos en local
    invalid = set(local) - set('abcdefghijklmnopqrstuvwxyz0123456789._%+-')
    if invalid:
        return False, f'Caracteres inválidos: {", ".join(sorted(invalid))}'
    if not _EMAIL_RE.match(e):
        return False, 'Formato de email inválido'
    return True, 'OK'


def check_tld_risk(domain: str) -> Tuple[bool, str]:
    tld = domain.rsplit('.', 1)[-1].lower()
    if tld in HIGH_RISK_TLDS:
        return True, f'TLD de alto riesgo: .{tld}'
    return False, ''


def check_role(email: str) -> Tuple[bool, str]:
    local = email.split('@')[0].lower()
    if local in ROLE_ACCOUNTS:
        return True, f'Cuenta de rol/sistema: {local}'
    for prefix in ROLE_PREFIXES:
        if local.startswith(prefix.rstrip('-@')):
            return True, f'Prefijo de rol detectado: {prefix}'
    # Patterns adicionales
    patterns = [r'noreply$', r'no-reply$', r'bounce$', r'donotreply$']
    for p in patterns:
        if re.search(p, local):
            return True, f'Sufijo de rol: {p}'
    return False, ''


def check_disposable(domain: str) -> bool:
    return domain.lower() in DISPOSABLE


def check_freemail(domain: str) -> bool:
    return domain.lower() in FREEMAIL


def check_domain_alive(domain: str) -> Tuple[bool, str]:
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 8
    resolver.nameservers = ['8.8.8.8', '1.1.1.1', '9.9.9.9']
    for rtype in ('A', 'NS', 'MX'):
        try:
            resolver.resolve(domain, rtype)
            return True, f'Dominio activo ({rtype} record encontrado)'
        except dns.resolver.NXDOMAIN:
            return False, 'Dominio no existe (NXDOMAIN)'
        except Exception:
            continue
    return False, 'Sin registros DNS activos'


def check_mx(domain: str, retries: int = 3) -> Tuple[bool, List[str], str]:
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 10
    resolver.nameservers = ['8.8.8.8', '1.1.1.1', '8.8.4.4', '9.9.9.9']
    last_err = 'Sin registros MX'
    for attempt in range(retries):
        try:
            answers = resolver.resolve(domain, 'MX')
            mx_list = sorted(
                [str(r.exchange).rstrip('.').lower() for r in answers]
            )
            return True, mx_list, 'OK'
        except dns.resolver.NXDOMAIN:
            return False, [], 'Dominio inexistente (NXDOMAIN)'
        except dns.resolver.NoAnswer:
            last_err = 'Sin registros MX configurados'
            break
        except dns.exception.Timeout:
            last_err = f'Timeout DNS (intento {attempt+1}/{retries})'
            time.sleep(0.5)
        except Exception as ex:
            last_err = str(ex)[:100]
            time.sleep(0.3)
    return False, [], last_err


def check_spf(domain: str) -> Tuple[Optional[bool], str]:
    """Verifica si el dominio tiene registro SPF (indica dominio de email legítimo)"""
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.nameservers = ['8.8.8.8', '1.1.1.1']
    try:
        answers = resolver.resolve(domain, 'TXT')
        for r in answers:
            txt = str(r).strip('"')
            if txt.startswith('v=spf1'):
                return True, f'SPF encontrado: {txt[:80]}'
        return False, 'Sin registro SPF'
    except Exception:
        return None, 'No se pudo verificar SPF'


def check_dmarc(domain: str) -> Tuple[Optional[bool], str]:
    """Verifica si el dominio tiene política DMARC"""
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.nameservers = ['8.8.8.8', '1.1.1.1']
    try:
        answers = resolver.resolve(f'_dmarc.{domain}', 'TXT')
        for r in answers:
            txt = str(r).strip('"')
            if 'v=DMARC1' in txt:
                return True, f'DMARC: {txt[:80]}'
        return False, 'Sin DMARC'
    except Exception:
        return None, 'No se pudo verificar DMARC'


def check_mx_antispam(mx_list: List[str]) -> Tuple[bool, str]:
    for mx in mx_list:
        for kw in ANTISPAM_MX:
            if kw in mx.lower():
                return True, f'Filtro antispam en MX: {kw} ({mx})'
    return False, ''


def check_mx_parked(mx_list: List[str]) -> Tuple[bool, str]:
    for mx in mx_list:
        for pat in PARKED_MX:
            if re.search(pat, mx.lower()):
                return True, f'Dominio parqueado detectado: {mx}'
    return False, ''


def check_mx_resolves(mx_list: List[str]) -> Tuple[bool, str]:
    """Verifica que al menos un MX resuelva a una IP real"""
    resolver = dns.resolver.Resolver()
    resolver.timeout = 3
    resolver.nameservers = ['8.8.8.8', '1.1.1.1']
    for mx in mx_list[:3]:
        try:
            resolver.resolve(mx, 'A')
            return True, f'MX resuelve correctamente: {mx}'
        except Exception:
            continue
    return False, 'Ningún MX resuelve a IP válida'


def smtp_verify(email: str, mx_list: List[str], timeout: int = 10) -> Tuple[str, str]:
    """
    Verificación SMTP con RCPT TO.
    Retorna: (status, mensaje)
    status: 'valid' | 'invalid' | 'catch-all' | 'unknown'
    """
    domain = email.split('@')[1]

    for mx in mx_list[:3]:
        try:
            smtp = smtplib.SMTP(timeout=timeout)
            smtp.connect(mx, 25)
            smtp.ehlo('emailverifier.local')

            code, _ = smtp.mail('probe@emailverifier.local')
            if code != 250:
                smtp.quit()
                continue

            code, msg_bytes = smtp.rcpt(email)
            msg_str = msg_bytes.decode('utf-8', errors='ignore') if isinstance(msg_bytes, bytes) else str(msg_bytes)

            if code == 250:
                # Test catch-all
                fake = f'zzz_noexiste_{int(time.time())}@{domain}'
                try:
                    code2, _ = smtp.rcpt(fake)
                    smtp.quit()
                    if code2 == 250:
                        return 'catch-all', 'Servidor acepta todo (catch-all)'
                    return 'valid', f'Email aceptado (250)'
                except Exception:
                    smtp.quit()
                    return 'valid', 'Email aceptado (250)'

            elif code in (550, 551, 553, 554, 556):
                smtp.quit()
                return 'invalid', f'Email rechazado por servidor ({code}): {msg_str[:100]}'

            elif code in (421, 450, 451, 452):
                smtp.quit()
                return 'unknown', f'Servidor ocupado/temporal ({code})'

            else:
                smtp.quit()
                return 'unknown', f'Respuesta no estándar ({code})'

        except smtplib.SMTPConnectError:
            continue
        except ConnectionRefusedError:
            continue
        except socket.timeout:
            continue
        except OSError:
            continue
        except smtplib.SMTPServerDisconnected:
            continue
        except Exception:
            continue

    return 'unknown', 'No se pudo conectar a ningún servidor MX (puerto 25 bloqueado o timeout)'


# ──────────────────────────────────────────────────────────────
# VERIFICADOR PRINCIPAL
# ──────────────────────────────────────────────────────────────

def verify_email(
    email: str,
    blacklisted_emails=None,
    blacklisted_domains=None,
    enable_smtp: bool = True,
    dns_retries: int = 3,
    smtp_timeout: int = 10,
) -> Dict:
    if blacklisted_emails is None:
        blacklisted_emails = set()
    if blacklisted_domains is None:
        blacklisted_domains = set()

    result = {
        'email': email.strip().lower() if email else '',
        'status': 'invalid',
        'reason': '',
        'checks': {},
        'syntax_valid': False,
        'is_role': False,
        'is_disposable': False,
        'is_freemail': False,
        'is_parked': False,
        'is_antispam': False,
        'dns_valid': False,
        'mx_records': [],
        'smtp_response': '',
        'spf': None,
        'dmarc': None,
        'score': 0,
    }
    e = result['email']

    # ── 1. Blacklist email ──────────────────────────────────
    if e in blacklisted_emails:
        result.update(status='blacklisted', reason='En lista negra personal')
        result['checks']['blacklist'] = '⛔ En blacklist de emails'
        return result

    # ── 2. Sintaxis ─────────────────────────────────────────
    ok, reason = check_syntax(e)
    result['syntax_valid'] = ok
    result['checks']['syntax'] = f'{"✅" if ok else "❌"} {reason}'
    if not ok:
        result['reason'] = reason
        return result
    result['score'] += 15

    local, domain = e.rsplit('@', 1)

    # ── 3. Blacklist dominio ─────────────────────────────────
    if domain in blacklisted_domains:
        result.update(status='blacklisted', reason=f'Dominio en lista negra: {domain}')
        result['checks']['domain_blacklist'] = f'⛔ Dominio blacklisted: {domain}'
        return result

    # ── 4. TLD de riesgo ────────────────────────────────────
    tld_risk, tld_reason = check_tld_risk(domain)
    result['checks']['tld'] = f'{"⚠️" if tld_risk else "✅"} {tld_reason if tld_risk else "TLD normal"}'
    if tld_risk:
        result['score'] -= 10  # Penaliza pero no descarta

    # ── 5. Cuenta de rol / spamtrap ─────────────────────────
    is_role, role_reason = check_role(e)
    result['is_role'] = is_role
    result['checks']['role'] = f'{"🚫" if is_role else "✅"} {role_reason if is_role else "No es cuenta de rol"}'
    if is_role:
        result.update(status='spamtrap', reason=role_reason)
        return result
    result['score'] += 10

    # ── 6. Email desechable ─────────────────────────────────
    result['is_disposable'] = check_disposable(domain)
    result['checks']['disposable'] = f'{"❌" if result["is_disposable"] else "✅"} {"Email desechable/temporal" if result["is_disposable"] else "No es desechable"}'
    if result['is_disposable']:
        result.update(status='invalid', reason='Dominio de email desechable/temporal')
        return result
    result['score'] += 10

    # ── 7. Freemail (informativo) ───────────────────────────
    result['is_freemail'] = check_freemail(domain)
    result['checks']['freemail'] = f'{"ℹ️" if result["is_freemail"] else "✅"} {"Email gratuito (gmail/yahoo/etc)" if result["is_freemail"] else "Dominio corporativo"}'
    # Freemail no descarta, solo informa

    # ── 8. Dominio activo ───────────────────────────────────
    alive, alive_reason = check_domain_alive(domain)
    result['checks']['domain_alive'] = f'{"✅" if alive else "❌"} {alive_reason}'
    if not alive:
        result.update(status='invalid', reason=f'Dominio inactivo/muerto: {alive_reason}')
        return result
    result['score'] += 10

    # ── 9. MX Records (3 intentos) ──────────────────────────
    has_mx, mx_list, mx_reason = check_mx(domain, retries=dns_retries)
    result['dns_valid'] = has_mx
    result['mx_records'] = mx_list
    result['checks']['mx'] = f'{"✅" if has_mx else "❌"} {mx_reason if not has_mx else "MX: " + ", ".join(mx_list[:2])}'
    if not has_mx:
        result.update(status='invalid', reason=f'Sin registros MX: {mx_reason}')
        return result
    result['score'] += 15

    # ── 10. MX resuelve a IP ────────────────────────────────
    mx_resolves, mx_resolve_reason = check_mx_resolves(mx_list)
    result['checks']['mx_resolves'] = f'{"✅" if mx_resolves else "⚠️"} {mx_resolve_reason}'
    if not mx_resolves:
        result['score'] -= 5

    # ── 11. Parqueado ───────────────────────────────────────
    is_pk, pk_reason = check_mx_parked(mx_list)
    result['is_parked'] = is_pk
    result['checks']['parked'] = f'{"❌" if is_pk else "✅"} {pk_reason if is_pk else "Dominio no parqueado"}'
    if is_pk:
        result.update(status='invalid', reason=pk_reason)
        return result
    result['score'] += 5

    # ── 12. Antispam MX ─────────────────────────────────────
    is_as, as_reason = check_mx_antispam(mx_list)
    result['is_antispam'] = is_as
    result['checks']['antispam'] = f'{"⚠️" if is_as else "✅"} {as_reason if is_as else "Sin filtros antispam en MX"}'
    if is_as:
        result['score'] -= 5
        # No descarta, pero marca risky

    # ── 13. SPF ─────────────────────────────────────────────
    spf_ok, spf_reason = check_spf(domain)
    result['spf'] = spf_ok
    result['checks']['spf'] = f'{"✅" if spf_ok else "⚠️" if spf_ok is False else "ℹ️"} {spf_reason}'
    if spf_ok:
        result['score'] += 5

    # ── 14. DMARC ───────────────────────────────────────────
    dmarc_ok, dmarc_reason = check_dmarc(domain)
    result['dmarc'] = dmarc_ok
    result['checks']['dmarc'] = f'{"✅" if dmarc_ok else "⚠️" if dmarc_ok is False else "ℹ️"} {dmarc_reason}'
    if dmarc_ok:
        result['score'] += 5

    # ── 15. SMTP ────────────────────────────────────────────
    if enable_smtp and not is_as:
        smtp_status, smtp_msg = smtp_verify(e, mx_list, timeout=smtp_timeout)
        result['smtp_response'] = smtp_msg
        result['checks']['smtp'] = f'{"✅" if smtp_status == "valid" else "⚠️" if smtp_status in ("catch-all","unknown") else "❌"} SMTP {smtp_status}: {smtp_msg[:80]}'

        if smtp_status == 'valid':
            result['score'] += 25
            result.update(status='valid', reason='Verificado exitosamente por SMTP')
        elif smtp_status == 'invalid':
            result.update(status='invalid', reason=f'Rechazado por servidor: {smtp_msg[:100]}')
        elif smtp_status == 'catch-all':
            result['score'] += 10
            result.update(status='risky', reason='Servidor catch-all (acepta todos los emails del dominio)')
        else:
            result['score'] += 5
            result['checks']['smtp'] += ' — Puerto 25 bloqueado por ISP es común en VPS'
            if not is_as:
                result.update(status='risky', reason=f'SMTP no concluyente: {smtp_msg[:100]}')
    elif is_as:
        result['smtp_response'] = 'Omitido (servidor antispam detectado)'
        result['checks']['smtp'] = '⚠️ SMTP omitido — servidor antispam bloquea verificación'
        result.update(status='risky', reason='Dominio protegido por antispam, no verificable directamente')
    else:
        result['smtp_response'] = 'Desactivado en configuración'
        result['checks']['smtp'] = 'ℹ️ Verificación SMTP desactivada'
        if result['score'] >= 50:
            result.update(status='risky', reason='Sin verificación SMTP — basado solo en DNS')

    result['score'] = max(0, min(100, result['score']))
    return result
