#!/bin/bash
# EmailVerifier Pro v2 — Instalador Ubuntu Server
# Uso: sudo bash install.sh
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

INSTALL_DIR="/opt/emailverifier"
APP_USER="www-data"
DB_NAME="emailverifier"
DB_USER="evdbuser"
DB_PASS=$(openssl rand -base64 32 | tr -d '/+=' | head -c 24)
SECRET_KEY=$(openssl rand -hex 32)

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
err()  { echo -e "${RED}[✗] ERROR: $1${NC}"; exit 1; }
step() { echo -e "\n${CYAN}${BOLD}[$1/10]${NC} $2"; }

echo -e "${CYAN}${BOLD}"
cat << 'BANNER'
╔══════════════════════════════════════════════════╗
║   EmailVerifier Pro v2.0 — Instalador Ubuntu     ║
║   Zona horaria: México (America/Merida)          ║
╚══════════════════════════════════════════════════╝
BANNER
echo -e "${NC}"

[ "$EUID" -ne 0 ] && err "Ejecutar como root: sudo bash install.sh"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -d "${SCRIPT_DIR}/app" ] || err "No se encontró directorio 'app/' junto a install.sh"

# ── 1. Sistema ──────────────────────────────────────────────
step 1 "Instalando dependencias del sistema..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq \
  python3 python3-pip python3-venv python3-dev \
  postgresql postgresql-contrib \
  redis-server nginx supervisor \
  curl wget dnsutils build-essential libpq-dev \
  unzip openssl
log "Dependencias instaladas"

# ── 2. PostgreSQL ────────────────────────────────────────────
step 2 "Configurando PostgreSQL..."
systemctl start postgresql && systemctl enable postgresql
sudo -u postgres psql -c "DROP DATABASE IF EXISTS ${DB_NAME};" 2>/dev/null || true
sudo -u postgres psql -c "DROP USER IF EXISTS ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"
sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"
log "PostgreSQL configurado"

# ── 3. Directorios ───────────────────────────────────────────
step 3 "Creando directorios en ${INSTALL_DIR}..."
mkdir -p ${INSTALL_DIR}/{uploads,results,logs,blacklists,static,routes}
mkdir -p ${INSTALL_DIR}/templates/admin
log "Directorios creados"

# ── 4. Copiar archivos ───────────────────────────────────────
step 4 "Copiando archivos de la aplicación..."
cp -r ${SCRIPT_DIR}/app/* ${INSTALL_DIR}/
log "Archivos copiados"

# ── 5. Python venv + dependencias ───────────────────────────
step 5 "Instalando dependencias Python..."
python3 -m venv ${INSTALL_DIR}/venv
${INSTALL_DIR}/venv/bin/pip install --quiet --upgrade pip setuptools wheel
${INSTALL_DIR}/venv/bin/pip install --quiet -r ${INSTALL_DIR}/requirements.txt
log "Entorno Python listo"

# ── 6. .env + base de datos ──────────────────────────────────
step 6 "Configurando base de datos..."
cat > ${INSTALL_DIR}/.env << ENVEOF
SECRET_KEY=${SECRET_KEY}
DATABASE_URL=postgresql://${DB_USER}:${DB_PASS}@localhost/${DB_NAME}
REDIS_URL=redis://localhost:6379/0
UPLOAD_FOLDER=${INSTALL_DIR}/uploads
RESULTS_FOLDER=${INSTALL_DIR}/results
BLACKLIST_FOLDER=${INSTALL_DIR}/blacklists
LOG_FOLDER=${INSTALL_DIR}/logs
FLASK_ENV=production
TZ=America/Merida
ENVEOF

# Inicializar DB
cd ${INSTALL_DIR}
${INSTALL_DIR}/venv/bin/python3 init_db.py || err "init_db.py falló — revisa logs arriba"
log "Base de datos inicializada"

# ── 7. Permisos ──────────────────────────────────────────────
step 7 "Configurando permisos..."
chown -R ${APP_USER}:${APP_USER} ${INSTALL_DIR}
chmod -R 755 ${INSTALL_DIR}
chmod 600 ${INSTALL_DIR}/.env
chmod 700 ${INSTALL_DIR}/uploads ${INSTALL_DIR}/results
log "Permisos listos"

# ── 8. Nginx ─────────────────────────────────────────────────
step 8 "Configurando Nginx..."
SERVER_IP=$(hostname -I | awk '{print $1}')
cat > /etc/nginx/sites-available/emailverifier << NGINXEOF
server {
    listen 80 default_server;
    server_name _;
    client_max_body_size 500M;
    client_body_timeout 600s;
    proxy_read_timeout 600s;

    location / {
        proxy_pass         http://127.0.0.1:5000;
        proxy_set_header   Host \$host;
        proxy_set_header   X-Real-IP \$remote_addr;
        proxy_set_header   X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 600s;
        proxy_buffering    off;
    }

    location /static/ {
        alias ${INSTALL_DIR}/static/;
        expires 7d;
        add_header Cache-Control "public";
    }

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    access_log /var/log/nginx/emailverifier_access.log;
    error_log  /var/log/nginx/emailverifier_error.log;
}
NGINXEOF
ln -sf /etc/nginx/sites-available/emailverifier /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && log "Nginx configurado" || err "Nginx config inválida"

# ── 9. Supervisor ────────────────────────────────────────────
step 9 "Configurando Supervisor..."
cat > /etc/supervisor/conf.d/ev-web.conf << SUPEOF
[program:ev-web]
command=${INSTALL_DIR}/venv/bin/gunicorn \
    --workers 4 \
    --worker-class eventlet \
    --bind 127.0.0.1:5000 \
    --timeout 600 \
    --keep-alive 5 \
    --access-logfile ${INSTALL_DIR}/logs/access.log \
    --error-logfile  ${INSTALL_DIR}/logs/gunicorn.log \
    app:app
directory=${INSTALL_DIR}
user=${APP_USER}
environment=PYTHONPATH="${INSTALL_DIR}",TZ="America/Merida"
autostart=true
autorestart=true
startsecs=10
startretries=5
redirect_stderr=true
stdout_logfile=${INSTALL_DIR}/logs/web_sup.log
SUPEOF

cat > /etc/supervisor/conf.d/ev-worker.conf << SUPEOF
[program:ev-worker]
command=${INSTALL_DIR}/venv/bin/celery \
    -A tasks \
    worker \
    --loglevel=info \
    --concurrency=4 \
    --logfile=${INSTALL_DIR}/logs/celery.log \
    -E
directory=${INSTALL_DIR}
user=${APP_USER}
environment=PYTHONPATH="${INSTALL_DIR}",TZ="America/Merida"
autostart=true
autorestart=true
startsecs=15
startretries=5
redirect_stderr=true
stdout_logfile=${INSTALL_DIR}/logs/worker_sup.log
SUPEOF
log "Supervisor configurado"

# ── 10. Iniciar servicios ────────────────────────────────────
step 10 "Iniciando servicios..."
systemctl enable redis-server && systemctl restart redis-server
systemctl enable supervisor  && systemctl restart supervisor
systemctl enable nginx       && systemctl restart nginx

sleep 5
supervisorctl reread
supervisorctl update
sleep 3
supervisorctl start ev-web    2>/dev/null || true
supervisorctl start ev-worker 2>/dev/null || true
sleep 6

WEB=$(supervisorctl status ev-web    2>/dev/null | grep -c RUNNING || echo 0)
WRK=$(supervisorctl status ev-worker 2>/dev/null | grep -c RUNNING || echo 0)

echo ""
echo -e "${GREEN}${BOLD}╔═══════════════════════════════════════════════════════╗"
echo -e "║         ✅  INSTALACIÓN COMPLETADA — v2.0              ║"
echo -e "╠═══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}${BOLD}║${NC}  🌐 Acceso:   ${CYAN}http://${SERVER_IP}${NC}"
echo -e "${GREEN}${BOLD}║${NC}  📁 Ruta:     ${INSTALL_DIR}"
echo -e "${GREEN}${BOLD}║${NC}  🕐 Zona:     America/Merida (CST/CDT)"
echo -e "${GREEN}${BOLD}║${NC}  Web App:   $([ "$WEB" = "1" ] && echo "${GREEN}✅ ACTIVO${NC}" || echo "${RED}❌ revisar logs${NC}")"
echo -e "${GREEN}${BOLD}║${NC}  Worker:    $([ "$WRK" = "1" ] && echo "${GREEN}✅ ACTIVO${NC}" || echo "${RED}❌ revisar logs${NC}")"
echo -e "${GREEN}${BOLD}╠═══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}${BOLD}║${NC}  ${YELLOW}Comandos útiles:${NC}"
echo -e "${GREEN}${BOLD}║${NC}  supervisorctl status"
echo -e "${GREEN}${BOLD}║${NC}  tail -f ${INSTALL_DIR}/logs/gunicorn.log"
echo -e "${GREEN}${BOLD}║${NC}  tail -f ${INSTALL_DIR}/logs/celery.log"
echo -e "${GREEN}${BOLD}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}  Si el worker no arranca: tail -f ${INSTALL_DIR}/logs/worker_sup.log${NC}"
