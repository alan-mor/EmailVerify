# EmailVerifier Pro 🚀

**El verificador de emails más completo y gratuito. Comparable a ZeroBounce y EmailListVerify.**

---

## 🔬 Técnicas de Verificación Aplicadas

| Verificación | Descripción |
|---|---|
| ✅ Sintaxis avanzada | Regex estricto: dobles @, caracteres inválidos, TLD, longitudes |
| ✅ Deduplicación | Elimina emails repetidos antes de procesar |
| ✅ Cuentas de rol | Detecta: noreply, postmaster, abuse, admin, spam, etc. (100+ palabras) |
| ✅ Spamtraps | Patrones de spamtrap conocidos |
| ✅ Emails desechables | Base de datos de 50+ proveedores desechables (mailinator, guerrillamail...) |
| ✅ DNS / MX (3 intentos) | Verifica que el dominio tenga registros MX con 3 reintentos |
| ✅ Dominio vivo | Comprueba que el dominio tenga registros A o NS activos |
| ✅ Dominios parqueados | Detecta dominios con MX de servicios de parking |
| ✅ Servicios antispam | Detecta ik2, spamexperts, proofpoint, mimecast, barracuda y 20+ más |
| ✅ Verificación SMTP | Conexión real al servidor MX con RCPT TO |
| ✅ Detección catch-all | Detecta servidores que aceptan cualquier email |
| ✅ Score 0-100 | Puntuación de calidad por email |
| ✅ Lista negra personal | Importa tus propias listas negras de emails y dominios |

---

## 🛠️ Instalación en Ubuntu Server

### Requisitos
- Ubuntu 20.04 / 22.04 / 24.04 LTS
- 1GB RAM mínimo (2GB recomendado)
- Acceso root

### Instalación
```bash
# 1. Descargar y descomprimir
unzip emailverifier-pro.zip
cd emailverifier-pro

# 2. Ejecutar instalador
sudo bash install.sh
```

El instalador hace todo automáticamente:
- Instala Python, PostgreSQL, Redis, Nginx, Supervisor
- Configura la base de datos
- Crea el usuario admin
- Configura nginx como proxy
- Inicia todos los servicios con supervisor (persiste en reinicio)

---

## 🖥️ Uso

### Acceso
Navega a `http://TU-IP-SERVIDOR` en el navegador.

### Formatos de archivo soportados
- `.TXT` — Un email por línea, o separados por coma
- `.CSV` — Cualquier columna que contenga emails
- `.XLSX / .XLS` — Cualquier celda que contenga emails

### Estados de resultado
| Estado | Descripción |
|---|---|
| ✅ **valid** | Email verificado y funcional |
| ⚠️ **risky** | Probablemente válido pero no verificable 100% (catch-all, antispam) |
| ❌ **invalid** | Email inválido (sin MX, dominio muerto, rechazado por SMTP) |
| 🚫 **spamtrap** | Cuenta de rol, postmaster, noreply, etc. |
| ⛔ **blacklisted** | En tu lista negra personal |
| 🔁 **duplicate** | Email duplicado en la lista original |

---

## ⚙️ Configuración

Accede a **Configuración** en el panel de admin para:
- Configurar SMTP para notificaciones por email
- Activar/desactivar verificación SMTP
- Ajustar workers, timeouts, reintentos DNS

---

## 📋 Comandos del servidor

```bash
# Ver estado de servicios
supervisorctl status

# Reiniciar todo
supervisorctl restart all

# Ver logs en tiempo real
tail -f /opt/emailverifier/logs/gunicorn.log
tail -f /opt/emailverifier/logs/celery.log

# Reiniciar nginx
systemctl restart nginx
```

---

## 🏗️ Arquitectura

```
emailverifier-pro/
├── install.sh          # Instalador único
└── app/
    ├── app.py          # Flask app + Celery
    ├── models.py       # Modelos PostgreSQL
    ├── verifier.py     # Motor de verificación
    ├── tasks.py        # Tareas background (Celery)
    ├── init_db.py      # Inicializar DB
    ├── requirements.txt
    ├── routes/
    │   ├── auth.py     # Login/logout
    │   ├── dashboard.py
    │   ├── verify.py   # Nueva verificación
    │   ├── admin.py    # Administración
    │   └── api.py      # API REST (status, cancel, test-smtp)
    └── templates/      # HTML (Jinja2)
```

**Stack tecnológico:**
- **Backend:** Python 3 + Flask
- **Colas:** Celery + Redis (procesa en background)
- **DB:** PostgreSQL
- **Servidor:** Gunicorn + Nginx
- **Process manager:** Supervisor (autostart en reinicio)

---

## 🔐 Seguridad

- Contraseñas almacenadas como SHA-512
- Sesiones persistentes con Flask-Login
- Cada usuario solo ve sus propios datos
- Solo el admin ve los datos de todos los usuarios
- Archivos de configuración con permisos 600

---

*EmailVerifier Pro v1.0 — Software libre*
