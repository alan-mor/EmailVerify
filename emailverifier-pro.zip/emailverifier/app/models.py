from app import db, login_manager
from flask_login import UserMixin
from datetime import datetime
import hashlib
import json


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    jobs = db.relationship('VerificationJob', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = hashlib.sha512(password.encode()).hexdigest()

    def check_password(self, password):
        return self.password_hash == hashlib.sha512(password.encode()).hexdigest()

    def check_hash(self, hash_value):
        return self.password_hash == hash_value


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class VerificationJob(db.Model):
    __tablename__ = 'verification_jobs'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, running, completed, failed
    celery_task_id = db.Column(db.String(200))
    total_emails = db.Column(db.Integer, default=0)
    processed_emails = db.Column(db.Integer, default=0)
    valid_count = db.Column(db.Integer, default=0)
    invalid_count = db.Column(db.Integer, default=0)
    risky_count = db.Column(db.Integer, default=0)
    duplicate_count = db.Column(db.Integer, default=0)
    spamtrap_count = db.Column(db.Integer, default=0)
    blacklisted_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    input_file = db.Column(db.String(500))
    result_file = db.Column(db.String(500))
    error_message = db.Column(db.Text)
    notify_email = db.Column(db.String(200))
    progress_log = db.Column(db.Text, default='[]')

    def get_progress_pct(self):
        if self.total_emails == 0:
            return 0
        return round((self.processed_emails / self.total_emails) * 100, 1)

    def add_log(self, message):
        try:
            logs = json.loads(self.progress_log or '[]')
        except:
            logs = []
        logs.append({'time': datetime.utcnow().isoformat(), 'msg': message})
        if len(logs) > 200:
            logs = logs[-200:]
        self.progress_log = json.dumps(logs)


class BlacklistDomain(db.Model):
    __tablename__ = 'blacklist_domains'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # None = global
    domain = db.Column(db.String(200), nullable=False)
    reason = db.Column(db.String(500))
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    added_by = db.Column(db.Integer, db.ForeignKey('users.id'))


class BlacklistEmail(db.Model):
    __tablename__ = 'blacklist_emails'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    email = db.Column(db.String(200), nullable=False)
    reason = db.Column(db.String(500))
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    added_by = db.Column(db.Integer, db.ForeignKey('users.id'))


class AppConfig(db.Model):
    __tablename__ = 'app_config'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    @classmethod
    def get(cls, key, default=None):
        r = cls.query.filter_by(key=key).first()
        return r.value if r else default

    @classmethod
    def set(cls, key, value):
        r = cls.query.filter_by(key=key).first()
        if r:
            r.value = value
            r.updated_at = datetime.utcnow()
        else:
            r = cls(key=key, value=value)
            db.session.add(r)
        db.session.commit()


class EmailResult(db.Model):
    __tablename__ = 'email_results'
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('verification_jobs.id'), nullable=False)
    email = db.Column(db.String(300), nullable=False)
    status = db.Column(db.String(20))  # valid, invalid, risky, spamtrap, blacklisted, duplicate
    reason = db.Column(db.String(500))
    mx_records = db.Column(db.Text)
    smtp_response = db.Column(db.String(500))
    is_disposable = db.Column(db.Boolean, default=False)
    is_role = db.Column(db.Boolean, default=False)
    is_parked = db.Column(db.Boolean, default=False)
    is_antispam = db.Column(db.Boolean, default=False)
    dns_valid = db.Column(db.Boolean)
    syntax_valid = db.Column(db.Boolean)
    score = db.Column(db.Integer, default=0)  # 0-100
    checked_at = db.Column(db.DateTime, default=datetime.utcnow)
