import hashlib
from flask import Blueprint, render_template, redirect, url_for, request, flash, abort, jsonify
from flask_login import login_required, current_user
from models import User, AppConfig, VerificationJob, EmailResult
from app import db
from datetime import datetime
import json

admin_bp = Blueprint('admin', __name__)


def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated


@admin_bp.route('/admin')
@login_required
@admin_required
def index():
    users = User.query.all()
    return render_template('admin/index.html', users=users)


@admin_bp.route('/admin/users', methods=['GET', 'POST'])
@login_required
@admin_required
def users():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'create':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '').strip()
            email = request.form.get('email', '').strip()
            is_admin = request.form.get('is_admin') == 'on'
            
            if not username or not password:
                flash('Username y password son requeridos', 'error')
            elif User.query.filter_by(username=username).first():
                flash('Username ya existe', 'error')
            else:
                user = User(username=username, email=email, is_admin=is_admin)
                user.set_password(password)
                db.session.add(user)
                db.session.commit()
                flash(f'Usuario {username} creado', 'success')
        
        elif action == 'toggle_active':
            uid = request.form.get('user_id')
            user = User.query.get(uid)
            if user and user.id != current_user.id:
                user.is_active = not user.is_active
                db.session.commit()
                flash(f'Usuario {user.username} {"activado" if user.is_active else "desactivado"}', 'success')
        
        elif action == 'change_password':
            uid = request.form.get('user_id')
            new_pass = request.form.get('new_password', '').strip()
            user = User.query.get(uid)
            if user and new_pass:
                user.set_password(new_pass)
                db.session.commit()
                flash(f'Contraseña cambiada para {user.username}', 'success')
        
        elif action == 'delete':
            uid = request.form.get('user_id')
            user = User.query.get(uid)
            if user and user.id != current_user.id:
                db.session.delete(user)
                db.session.commit()
                flash(f'Usuario eliminado', 'success')
        
        return redirect(url_for('admin.users'))
    
    all_users = User.query.all()
    return render_template('admin/users.html', users=all_users)


@admin_bp.route('/admin/config', methods=['GET', 'POST'])
@login_required
@admin_required
def config():
    if request.method == 'POST':
        config_keys = [
            'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_from',
            'smtp_ssl', 'enable_smtp_verify', 'dns_retries', 'smtp_timeout',
            'max_workers', 'site_name', 'site_url'
        ]
        for key in config_keys:
            val = request.form.get(key, '').strip()
            if val is not None:
                AppConfig.set(key, val)
        
        # Password de smtp es sensible
        flash('Configuración guardada correctamente', 'success')
        return redirect(url_for('admin.config'))
    
    cfg = {
        'smtp_host': AppConfig.get('smtp_host', ''),
        'smtp_port': AppConfig.get('smtp_port', '587'),
        'smtp_user': AppConfig.get('smtp_user', ''),
        'smtp_pass': AppConfig.get('smtp_pass', ''),
        'smtp_from': AppConfig.get('smtp_from', ''),
        'smtp_ssl': AppConfig.get('smtp_ssl', 'tls'),
        'enable_smtp_verify': AppConfig.get('enable_smtp_verify', 'true'),
        'dns_retries': AppConfig.get('dns_retries', '3'),
        'smtp_timeout': AppConfig.get('smtp_timeout', '10'),
        'max_workers': AppConfig.get('max_workers', '10'),
        'site_name': AppConfig.get('site_name', 'EmailVerifier Pro'),
        'site_url': AppConfig.get('site_url', ''),
    }
    
    return render_template('admin/config.html', cfg=cfg)


@admin_bp.route('/admin/all-jobs')
@login_required
@admin_required
def all_jobs():
    jobs = VerificationJob.query.order_by(VerificationJob.created_at.desc()).all()
    users = {u.id: u.username for u in User.query.all()}
    return render_template('admin/all_jobs.html', jobs=jobs, users=users)


# ─────────────────────────────────────────────
# API Blueprint
# ─────────────────────────────────────────────

api_bp = Blueprint('api', __name__)


@api_bp.route('/job/<int:job_id>/status')
@login_required
def job_status(job_id):
    job = VerificationJob.query.get_or_404(job_id)
    if not current_user.is_admin and job.user_id != current_user.id:
        abort(403)
    
    try:
        logs = json.loads(job.progress_log or '[]')
    except:
        logs = []
    
    return jsonify({
        'id': job.id,
        'status': job.status,
        'progress': job.get_progress_pct(),
        'processed': job.processed_emails,
        'total': job.total_emails,
        'valid': job.valid_count,
        'invalid': job.invalid_count,
        'risky': job.risky_count,
        'spamtrap': job.spamtrap_count,
        'blacklisted': job.blacklisted_count,
        'duplicate': job.duplicate_count,
        'logs': logs[-20:],  # Últimos 20 logs
        'result_file': job.result_file,
        'error': job.error_message
    })


@api_bp.route('/test-smtp', methods=['POST'])
@login_required
def test_smtp():
    if not current_user.is_admin:
        abort(403)
    
    import smtplib
    data = request.get_json()
    try:
        host = data.get('smtp_host')
        port = int(data.get('smtp_port', 587))
        user = data.get('smtp_user')
        pwd = data.get('smtp_pass')
        ssl = data.get('smtp_ssl', 'tls')
        
        if ssl == 'ssl':
            s = smtplib.SMTP_SSL(host, port, timeout=10)
        else:
            s = smtplib.SMTP(host, port, timeout=10)
            if ssl == 'tls':
                s.starttls()
        
        if user and pwd:
            s.login(user, pwd)
        s.quit()
        return jsonify({'ok': True, 'message': 'Conexión SMTP exitosa'})
    except Exception as e:
        return jsonify({'ok': False, 'message': str(e)})


@api_bp.route('/job/<int:job_id>/cancel', methods=['POST'])
@login_required
def cancel_job(job_id):
    job = VerificationJob.query.get_or_404(job_id)
    if not current_user.is_admin and job.user_id != current_user.id:
        abort(403)
    
    if job.status in ('pending', 'running'):
        from app import celery as celery_app
        if job.celery_task_id:
            celery_app.control.revoke(job.celery_task_id, terminate=True)
        job.status = 'failed'
        job.error_message = 'Cancelado por el usuario'
        db.session.commit()
    
    return jsonify({'ok': True})
