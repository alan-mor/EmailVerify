import os
import uuid
from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app, jsonify
from flask_login import login_required, current_user
from models import VerificationJob, BlacklistEmail, BlacklistDomain
from app import db
from tasks import run_verification
from datetime import datetime

verify_bp = Blueprint('verify', __name__)

ALLOWED_EXTENSIONS = {'txt', 'csv', 'xlsx', 'xls'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@verify_bp.route('/verify', methods=['GET', 'POST'])
@login_required
def new_verification():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        notify_email = request.form.get('notify_email', '').strip()
        
        if not name:
            flash('El nombre del trabajo es requerido', 'error')
            return redirect(url_for('verify.new_verification'))
        
        if 'file' not in request.files:
            flash('No se seleccionó ningún archivo', 'error')
            return redirect(url_for('verify.new_verification'))
        
        file = request.files['file']
        if file.filename == '' or not allowed_file(file.filename):
            flash('Archivo inválido. Use TXT, CSV o XLSX', 'error')
            return redirect(url_for('verify.new_verification'))
        
        # Guardar archivo
        upload_folder = current_app.config['UPLOAD_FOLDER']
        os.makedirs(upload_folder, exist_ok=True)
        
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = f"{uuid.uuid4().hex}.{ext}"
        filepath = os.path.join(upload_folder, filename)
        file.save(filepath)
        
        # Crear job
        job = VerificationJob(
            user_id=current_user.id,
            name=name,
            status='pending',
            input_file=filepath,
            notify_email=notify_email if notify_email else None,
            created_at=datetime.utcnow()
        )
        db.session.add(job)
        db.session.commit()
        
        # Lanzar tarea en background
        task = run_verification.delay(job.id)
        job.celery_task_id = task.id
        db.session.commit()
        
        flash(f'Verificación "{name}" iniciada correctamente', 'success')
        return redirect(url_for('dashboard.job_detail', job_id=job.id))
    
    return render_template('new_verification.html')


@verify_bp.route('/blacklist', methods=['GET', 'POST'])
@login_required
def blacklist():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'add_email':
            email = request.form.get('email', '').strip().lower()
            reason = request.form.get('reason', '').strip()
            if email and '@' in email:
                existing = BlacklistEmail.query.filter_by(email=email, user_id=current_user.id).first()
                if not existing:
                    b = BlacklistEmail(email=email, reason=reason, 
                                      user_id=current_user.id, added_by=current_user.id)
                    db.session.add(b)
                    db.session.commit()
                    flash(f'Email {email} agregado a lista negra', 'success')
        
        elif action == 'add_domain':
            domain = request.form.get('domain', '').strip().lower()
            reason = request.form.get('reason', '').strip()
            if domain and '.' in domain:
                existing = BlacklistDomain.query.filter_by(domain=domain, user_id=current_user.id).first()
                if not existing:
                    b = BlacklistDomain(domain=domain, reason=reason,
                                       user_id=current_user.id, added_by=current_user.id)
                    db.session.add(b)
                    db.session.commit()
                    flash(f'Dominio {domain} agregado a lista negra', 'success')
        
        elif action == 'import_file':
            if 'blacklist_file' in request.files:
                f = request.files['blacklist_file']
                content = f.read().decode('utf-8', errors='ignore')
                added = 0
                for line in content.splitlines():
                    item = line.strip().lower()
                    if not item:
                        continue
                    if '@' in item:
                        existing = BlacklistEmail.query.filter_by(email=item, user_id=current_user.id).first()
                        if not existing:
                            db.session.add(BlacklistEmail(email=item, user_id=current_user.id, 
                                                          added_by=current_user.id))
                            added += 1
                    elif '.' in item:
                        existing = BlacklistDomain.query.filter_by(domain=item, user_id=current_user.id).first()
                        if not existing:
                            db.session.add(BlacklistDomain(domain=item, user_id=current_user.id,
                                                           added_by=current_user.id))
                            added += 1
                db.session.commit()
                flash(f'{added} entradas importadas a lista negra', 'success')
        
        elif action == 'delete_email':
            item_id = request.form.get('id')
            b = BlacklistEmail.query.get(item_id)
            if b and (b.user_id == current_user.id or current_user.is_admin):
                db.session.delete(b)
                db.session.commit()
        
        elif action == 'delete_domain':
            item_id = request.form.get('id')
            b = BlacklistDomain.query.get(item_id)
            if b and (b.user_id == current_user.id or current_user.is_admin):
                db.session.delete(b)
                db.session.commit()
        
        return redirect(url_for('verify.blacklist'))
    
    blacklisted_emails = BlacklistEmail.query.filter_by(user_id=current_user.id).all()
    blacklisted_domains = BlacklistDomain.query.filter_by(user_id=current_user.id).all()
    
    return render_template('blacklist.html', 
                          emails=blacklisted_emails, 
                          domains=blacklisted_domains)
