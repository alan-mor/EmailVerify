from flask import Blueprint, render_template, redirect, url_for, request, send_file, abort
from flask_login import login_required, current_user
from models import VerificationJob, EmailResult, User
from app import db
import os

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/dashboard')
@login_required
def index():
    if current_user.is_admin:
        jobs = VerificationJob.query.order_by(VerificationJob.created_at.desc()).limit(50).all()
        users = User.query.all()
    else:
        jobs = VerificationJob.query.filter_by(user_id=current_user.id)\
            .order_by(VerificationJob.created_at.desc()).limit(50).all()
        users = None
    
    stats = {
        'total_jobs': len(jobs),
        'total_emails': sum(j.total_emails for j in jobs),
        'total_valid': sum(j.valid_count for j in jobs),
        'total_invalid': sum(j.invalid_count for j in jobs),
        'running': sum(1 for j in jobs if j.status == 'running'),
    }
    
    return render_template('dashboard.html', jobs=jobs, stats=stats, users=users)


@dashboard_bp.route('/job/<int:job_id>')
@login_required
def job_detail(job_id):
    job = VerificationJob.query.get_or_404(job_id)
    if not current_user.is_admin and job.user_id != current_user.id:
        abort(403)
    
    results = EmailResult.query.filter_by(job_id=job_id).limit(500).all()
    
    return render_template('job_detail.html', job=job, results=results)


@dashboard_bp.route('/download/<int:job_id>')
@login_required
def download_results(job_id):
    job = VerificationJob.query.get_or_404(job_id)
    if not current_user.is_admin and job.user_id != current_user.id:
        abort(403)
    
    if not job.result_file:
        abort(404)
    
    results_folder = os.getenv('RESULTS_FOLDER', 'results')
    filepath = os.path.join(results_folder, job.result_file)
    
    if not os.path.exists(filepath):
        abort(404)
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name=f'verificacion_{job.name.replace(" ", "_")}_{job.id}.csv',
        mimetype='text/csv'
    )
