"""
Inicialización de la base de datos
Crea tablas y usuario admin inicial
"""

import os
import sys
import hashlib

# Agregar directorio al path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app, db
from models import User, AppConfig

app = create_app()

with app.app_context():
    # Crear todas las tablas
    db.create_all()
    print("✅ Tablas creadas correctamente")
    
    # Crear usuario admin inicial si no existe
    admin = User.query.filter_by(username='alanmor').first()
    if not admin:
        admin = User(
            username='alanmor',
            is_admin=True,
            is_active=True,
            email=None
        )
        # Hash SHA512 preestablecido
        admin.password_hash = '567ee3dadc9d4b1ea71ea34885129cd890fdf0dc6f722beee378481fb0352166fa571013c89605403f1316a60331dbd1b2b03e9fd37f5be4490d885d43839a96'
        db.session.add(admin)
        db.session.commit()
        print("✅ Usuario administrador creado")
    else:
        print("ℹ️  Usuario administrador ya existe")
    
    # Configuración por defecto
    defaults = {
        'smtp_host': '',
        'smtp_port': '587',
        'smtp_user': '',
        'smtp_pass': '',
        'smtp_from': '',
        'smtp_ssl': 'tls',
        'enable_smtp_verify': 'true',
        'dns_retries': '3',
        'smtp_timeout': '10',
        'max_workers': '10',
        'site_name': 'EmailVerifier Pro',
        'site_url': '',
    }
    
    for key, val in defaults.items():
        if not AppConfig.get(key):
            AppConfig.set(key, val)
    
    print("✅ Configuración inicial establecida")
    print("")
    print("🚀 Base de datos inicializada correctamente")
    print("   Accede con las credenciales del administrador")
