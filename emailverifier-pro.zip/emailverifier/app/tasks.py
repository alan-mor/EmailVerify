"""
Tareas en background con Celery
Las verificaciones corren en segundo plano aunque el usuario cierre el navegador
"""

import os
import csv
import json
import time
import logging
import hashlib
import smtplib
import tempfile
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Set

import pandas as pd
from app import celery, db
from models import VerificationJob, EmailResult, BlacklistDomain, BlacklistEmail, AppConfig
from verifier import verify_email, check_syntax

logger = logging.getLogger(__name__)


def get_blacklists(user_id: int):
    """Obtiene las listas negras globales y del usuario"""
    # Emails blacklisted
    email_blacklist = set()
    rows = BlacklistEmail.query.filter(
        (BlacklistEmail.user_id == user_id) | (BlacklistEmail.user_id == None)
    ).all()
    for r in rows:
        email_blacklist.add(r.email.lower().strip())
    
    # Dominios blacklisted
    domain_blacklist = set()
    rows = BlacklistDomain.query.filter(
        (BlacklistDomain.user_id == user_id) | (BlacklistDomain.user_id == None)
    ).all()
    for r in rows:
        domain_blacklist.add(r.domain.lower().strip())
    
    return email_blacklist, domain_blacklist


def parse_email_file(filepath: str) -> List[str]:
    """
    Parsea archivos TXT, CSV o XLSX y extrae emails.
    Retorna lista de emails (sin normalizar aún).
    """
    ext = os.path.splitext(filepath)[1].lower()
    emails = []
    
    if ext == '.txt':
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line and '@' in line:
                    # Puede ser solo email o CSV en txt
                    parts = [p.strip() for p in line.split(',')]
                    for part in parts:
                        if '@' in part:
                            emails.append(part.strip('"').strip("'"))
    
    elif ext == '.csv':
        try:
            df = pd.read_csv(filepath, header=None, dtype=str, encoding='utf-8', 
                           error_bad_lines=False, on_bad_lines='skip')
        except Exception:
            df = pd.read_csv(filepath, header=None, dtype=str, encoding='latin-1',
                           on_bad_lines='skip')
        
        for col in df.columns:
            series = df[col].dropna().astype(str)
            for val in series:
                val = val.strip()
                if '@' in val and '.' in val:
                    emails.append(val)
    
    elif ext in ('.xlsx', '.xls'):
        df = pd.read_excel(filepath, header=None, dtype=str)
        for col in df.columns:
            series = df[col].dropna().astype(str)
            for val in series:
                val = val.strip()
                if '@' in val and '.' in val:
                    emails.append(val)
    
    return emails


def deduplicate(emails: List[str]) -> tuple:
    """Elimina duplicados, retorna (emails_únicos, count_duplicados)"""
    seen = set()
    unique = []
    dupes = 0
    for email in emails:
        normalized = email.strip().lower()
        if normalized and normalized not in seen:
            seen.add(normalized)
            unique.append(normalized)
        elif normalized:
            dupes += 1
    return unique, dupes


def send_completion_email(job: VerificationJob):
    """Envía email de notificación cuando termina el trabajo"""
    if not job.notify_email:
        return
    
    smtp_host = AppConfig.get('smtp_host', '')
    smtp_port = int(AppConfig.get('smtp_port', '587'))
    smtp_user = AppConfig.get('smtp_user', '')
    smtp_pass = AppConfig.get('smtp_pass', '')
    smtp_from = AppConfig.get('smtp_from', smtp_user)
    smtp_ssl = AppConfig.get('smtp_ssl', 'tls')
    
    if not smtp_host or not smtp_user:
        return
    
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f'✅ Verificación completada: {job.name}'
        msg['From'] = smtp_from
        msg['To'] = job.notify_email
        
        html = f"""
        <html><body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #0f172a; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
            <h2>✅ Verificación Completada</h2>
        </div>
        <div style="border: 1px solid #e2e8f0; padding: 20px; border-radius: 0 0 8px 8px;">
            <h3>{job.name}</h3>
            <table style="width:100%; border-collapse: collapse;">
                <tr><td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><strong>Total emails</strong></td><td>{job.total_emails}</td></tr>
                <tr style="background:#f0fdf4;"><td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><strong>✅ Válidos</strong></td><td>{job.valid_count}</td></tr>
                <tr><td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><strong>⚠️ Riesgosos</strong></td><td>{job.risky_count}</td></tr>
                <tr><td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><strong>❌ Inválidos</strong></td><td>{job.invalid_count}</td></tr>
                <tr><td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><strong>🗑️ Duplicados</strong></td><td>{job.duplicate_count}</td></tr>
                <tr><td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><strong>🚫 Spamtraps</strong></td><td>{job.spamtrap_count}</td></tr>
                <tr><td style="padding: 8px;"><strong>⛔ Blacklisted</strong></td><td>{job.blacklisted_count}</td></tr>
            </table>
            <p style="margin-top: 20px; color: #64748b;">Puedes descargar los resultados desde el panel de control.</p>
        </div>
        </body></html>
        """
        
        msg.attach(MIMEText(html, 'html'))
        
        if smtp_ssl == 'ssl':
            server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=30)
        else:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=30)
            if smtp_ssl == 'tls':
                server.starttls()
        
        if smtp_user and smtp_pass:
            server.login(smtp_user, smtp_pass)
        
        server.sendmail(smtp_from, [job.notify_email], msg.as_string())
        server.quit()
        
    except Exception as e:
        logger.error(f"Error enviando email de notificación: {e}")


def save_results_csv(job: VerificationJob, results_folder: str) -> str:
    """Guarda los resultados en CSV"""
    filename = f"job_{job.id}_{int(time.time())}.csv"
    filepath = os.path.join(results_folder, filename)
    
    results = EmailResult.query.filter_by(job_id=job.id).all()
    
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            'Email', 'Estado', 'Razón', 'Sintaxis OK', 
            'Es Rol/Spamtrap', 'Es Desechable', 'Es Parqueado',
            'Es Antispam', 'DNS Válido', 'Registros MX', 
            'Respuesta SMTP', 'Score', 'Verificado'
        ])
        for r in results:
            writer.writerow([
                r.email, r.status, r.reason,
                '✓' if r.syntax_valid else '✗',
                '✓' if r.is_role else '✗',
                '✓' if r.is_disposable else '✗',
                '✓' if r.is_parked else '✗',
                '✓' if r.is_antispam else '✗',
                '✓' if r.dns_valid else '✗',
                r.mx_records or '',
                r.smtp_response or '',
                r.score,
                r.checked_at.strftime('%Y-%m-%d %H:%M:%S')
            ])
    
    return filename


@celery.task(bind=True, name='tasks.run_verification')
def run_verification(self, job_id: int):
    """
    Tarea principal de verificación - corre en background.
    Persiste aunque el usuario cierre el navegador.
    """
    from app import create_app
    
    job = VerificationJob.query.get(job_id)
    if not job:
        return {'error': f'Job {job_id} no encontrado'}
    
    try:
        job.status = 'running'
        job.started_at = datetime.utcnow()
        job.add_log('🚀 Iniciando verificación...')
        db.session.commit()
        
        # Configuración
        enable_smtp = AppConfig.get('enable_smtp_verify', 'true').lower() == 'true'
        dns_retries = int(AppConfig.get('dns_retries', '3'))
        smtp_timeout = int(AppConfig.get('smtp_timeout', '10'))
        results_folder = os.getenv('RESULTS_FOLDER', 'results')
        
        # Leer archivo
        job.add_log('📂 Leyendo archivo de emails...')
        db.session.commit()
        
        raw_emails = parse_email_file(job.input_file)
        job.add_log(f'📧 {len(raw_emails)} emails encontrados en el archivo')
        db.session.commit()
        
        # Deduplicar
        unique_emails, dupe_count = deduplicate(raw_emails)
        job.duplicate_count = dupe_count
        job.total_emails = len(unique_emails) + dupe_count
        job.add_log(f'🔄 Deduplicación: {dupe_count} duplicados eliminados, {len(unique_emails)} únicos')
        db.session.commit()
        
        # Guardar duplicados como tal
        if dupe_count > 0:
            seen = set()
            for email in [e.strip().lower() for e in raw_emails if e.strip()]:
                if email in seen:
                    r = EmailResult(
                        job_id=job_id,
                        email=email,
                        status='duplicate',
                        reason='Email duplicado en la lista',
                        syntax_valid=True,
                        score=0
                    )
                    db.session.add(r)
                else:
                    seen.add(email)
            db.session.commit()
        
        # Obtener blacklists
        email_blacklist, domain_blacklist = get_blacklists(job.user_id)
        job.add_log(f'⛔ Blacklists cargadas: {len(email_blacklist)} emails, {len(domain_blacklist)} dominios')
        db.session.commit()
        
        # Verificar emails
        valid_count = 0
        invalid_count = 0
        risky_count = 0
        spamtrap_count = 0
        blacklisted_count = 0
        
        batch_size = 50
        for i, email in enumerate(unique_emails):
            try:
                result = verify_email(
                    email,
                    blacklisted_emails=email_blacklist,
                    blacklisted_domains=domain_blacklist,
                    enable_smtp=enable_smtp,
                    dns_retries=dns_retries,
                    smtp_timeout=smtp_timeout
                )
                
                # Contar
                status = result['status']
                if status == 'valid':
                    valid_count += 1
                elif status == 'invalid':
                    invalid_count += 1
                elif status == 'risky':
                    risky_count += 1
                elif status == 'spamtrap':
                    spamtrap_count += 1
                elif status == 'blacklisted':
                    blacklisted_count += 1
                
                # Guardar resultado
                mx_str = ', '.join(result.get('mx_records', []))[:500] if result.get('mx_records') else ''
                er = EmailResult(
                    job_id=job_id,
                    email=result['email'],
                    status=status,
                    reason=result.get('reason', '')[:500],
                    syntax_valid=result.get('syntax_valid', False),
                    is_role=result.get('is_role', False),
                    is_disposable=result.get('is_disposable', False),
                    is_parked=result.get('is_parked', False),
                    is_antispam=result.get('is_antispam', False),
                    dns_valid=result.get('dns_valid', False),
                    mx_records=mx_str,
                    smtp_response=result.get('smtp_response', '')[:500],
                    score=result.get('score', 0)
                )
                db.session.add(er)
                
                # Commit en batches
                if (i + 1) % batch_size == 0:
                    job.processed_emails = i + 1
                    job.valid_count = valid_count
                    job.invalid_count = invalid_count
                    job.risky_count = risky_count
                    job.spamtrap_count = spamtrap_count
                    job.blacklisted_count = blacklisted_count
                    
                    pct = round(((i + 1) / len(unique_emails)) * 100, 1)
                    job.add_log(f'⚡ Progreso: {i+1}/{len(unique_emails)} ({pct}%) - ✅{valid_count} ❌{invalid_count} ⚠️{risky_count}')
                    db.session.commit()
            
            except Exception as e:
                logger.error(f"Error verificando {email}: {e}")
                er = EmailResult(
                    job_id=job_id,
                    email=email,
                    status='invalid',
                    reason=f'Error en verificación: {str(e)[:200]}',
                    score=0
                )
                db.session.add(er)
        
        # Commit final
        job.processed_emails = len(unique_emails)
        job.valid_count = valid_count
        job.invalid_count = invalid_count
        job.risky_count = risky_count
        job.spamtrap_count = spamtrap_count
        job.blacklisted_count = blacklisted_count
        job.status = 'completed'
        job.completed_at = datetime.utcnow()
        
        # Generar CSV de resultados
        job.add_log('💾 Generando archivo de resultados...')
        db.session.commit()
        
        result_filename = save_results_csv(job, results_folder)
        job.result_file = result_filename
        job.add_log(f'✅ ¡Verificación completada! {len(unique_emails)} emails procesados.')
        job.add_log(f'📊 Resultados: ✅ Válidos: {valid_count} | ❌ Inválidos: {invalid_count} | ⚠️ Riesgosos: {risky_count} | 🚫 Spamtraps: {spamtrap_count}')
        db.session.commit()
        
        # Notificación por email
        send_completion_email(job)
        
        return {
            'status': 'completed',
            'job_id': job_id,
            'total': job.total_emails,
            'valid': valid_count,
            'invalid': invalid_count,
            'risky': risky_count,
            'spamtrap': spamtrap_count,
            'blacklisted': blacklisted_count,
            'duplicates': dupe_count
        }
    
    except Exception as e:
        logger.error(f"Error fatal en job {job_id}: {e}")
        job = VerificationJob.query.get(job_id)
        if job:
            job.status = 'failed'
            job.error_message = str(e)
            job.add_log(f'❌ Error fatal: {str(e)}')
            db.session.commit()
        return {'error': str(e)}
