"""
EmailVerifier Pro - Motor de Verificación
El núcleo de verificación con todas las técnicas profesionales
"""

import re
import dns.resolver
import dns.exception
import socket
import smtplib
import time
import logging
from typing import Dict, List, Optional, Tuple
import tldextract

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# LISTAS DE DETECCIÓN
# ─────────────────────────────────────────────

ROLE_ACCOUNTS = {
    'noreply', 'no-reply', 'noreply', 'no_reply', 'donotreply', 'do-not-reply',
    'do_not_reply', 'postmaster', 'mailer-daemon', 'mailer_daemon', 'mailerdaemon',
    'antispam', 'anti-spam', 'anti_spam', 'spam', 'spamtrap', 'spam-trap',
    'abuse', 'security', 'hostmaster', 'usenet', 'news', 'webmaster',
    'www', 'uucp', 'ftp', 'root', 'operator', 'daemon', 'bin', 'sys',
    'nobody', 'null', 'devnull', 'dev-null', 'blackhole', 'bounce',
    'bounces', 'ndr', 'return', 'returns', 'unsubscribe', 'subscribe',
    'newsletter', 'notifications', 'notification', 'alerts', 'alert',
    'info', 'information', 'help', 'helpdesk', 'help-desk', 'support',
    'admin', 'administrator', 'sysadmin', 'sys-admin', 'contact',
    'sales', 'marketing', 'billing', 'invoices', 'invoice', 'accounts',
    'account', 'service', 'services', 'team', 'office', 'staff',
    'mail', 'email', 'mailbox', 'inbox', 'test', 'testing', 'demo',
    'example', 'sample', 'anonymous', 'anon', 'delete', 'deleted',
    'removed', 'invalid', 'unknown', 'undisclosed', 'recipient',
    'recipients', 'feedback', 'reply', 'replies', 'autoresponder',
    'auto-responder', 'auto_responder', 'vacation', 'out-of-office',
    'outofoffice', 'ops', 'operations', 'legal', 'hr', 'humanresources',
    'it', 'tech', 'techsupport', 'register', 'registration', 'confirm',
    'confirmation', 'verify', 'verification', 'activate', 'activation',
    'password', 'reset', 'welcome', 'system', 'automated', 'automatic',
    'robot', 'bot', 'crawler', 'spider', 'scraper', 'network', 'monitoring',
    'monitor', 'report', 'reports', 'analytics', 'stats', 'statistics',
    'press', 'media', 'pr', 'publicrelations', 'partnerships', 'partner',
    'vendor', 'suppliers', 'supplier', 'procurement', 'orders', 'order',
    'shipping', 'delivery', 'logistics', 'warehouse', 'store', 'shop',
    'ecommerce', 'payment', 'payments', 'finance', 'financial', 'tax',
    'vat', 'compliance', 'privacy', 'gdpr', 'dpo', 'legal-notices',
    'catch-all', 'catchall', 'hostmaster', 'dns', 'smtp', 'imap', 'pop3',
    'fax', 'calendar', 'scheduler', 'cron', 'jobs', 'job', 'careers',
    'career', 'hiring', 'recruitment', 'recruiter',
}

ANTISPAM_MX_KEYWORDS = [
    'ik2', 'spamexperts', 'spamhero', 'spamsoap', 'antispamcloud',
    'mxlogic', 'postini', 'messagelabs', 'symanteccloud', 'proofpoint',
    'pphosted', 'barracuda', 'cudamail', 'reflexion', 'solarwinds',
    'appriver', 'exclaimer', 'mimecast', 'hornetsecurity', 'mailprotect',
    'mailscanner', 'spamfilter', 'antispam', 'spam-filter', 'maildefense',
    'mailcleaner', 'mailwasher', 'mailprotector', 'cleanmx', 'mailpure',
    'spamblocker', 'mailguard', 'mailsecurity', 'mailgate', 'mailarmor',
    'spamtitan', 'securence', 'zixmail', 'zixcorp', 'trustifi',
    'avanan', 'abnormalsecurity', 'ironscales', 'cofense',
    'agari', 'vade', 'vadesecure', 'mailroute', 'mailhop',
    'returnpath', 'validity', 'spamcop', 'cloudmark', 'senderscore',
]

PARKED_MX_KEYWORDS = [
    'sedoparking', 'parkingcrew', 'bodis', 'above.com', 'hugedomains',
    'domainmonster', 'godaddy.*park', 'parked', 'sinkhole', 'blackhole',
    'parking', 'domain-for-sale', 'domainseller', 'undeveloped',
    'afternic', 'dan.com', 'squadhelp', 'epik.com', 'uniregistry',
    'brandbucket', 'flippa', 'sedo.com', 'namejet', 'snapnames',
]

DISPOSABLE_DOMAINS = {
    'mailinator.com', 'guerrillamail.com', 'tempmail.com', 'throwam.com',
    'yopmail.com', 'sharklasers.com', 'guerrillamailblock.com',
    'grr.la', 'guerrillamail.info', 'guerrillamail.biz', 'guerrillamail.de',
    'guerrillamail.net', 'guerrillamail.org', 'spam4.me', 'trashmail.com',
    'trashmail.me', 'trashmail.net', 'dispostable.com', 'mailnull.com',
    'spamgourmet.com', 'spamgourmet.net', 'spamgourmet.org',
    'spamfree24.org', 'spamfree24.de', 'spamfree24.eu', 'spamfree24.info',
    'spamfree24.net', 'spamfree24.com', '10minutemail.com',
    '10minutemail.net', '10minutemail.org', 'tempinbox.com',
    'tempr.email', 'discard.email', 'spamherelots.com',
    'mailnew.com', 'mailscrap.com', 'maildrop.cc', 'mailnesia.com',
    'mailnull.com', 'mailrock.biz', 'getnada.com', 'inoutmail.eu',
    'tempinbox.de', 'spamhere.eu', 'throwam.com', 'mohmal.com',
    'safetymail.info', 'tempail.com', 'mailexpire.com', 'jetable.fr.nf',
    'trashmail.at', 'trashmail.io', 'trashmail.xyz', 'wegwerfmail.de',
    'tempmail.ninja', 'tempmail.plus', 'fakemail.net', 'dispostable.com',
    'throwam.com', 'sharklasers.com', 'guerrillamail.com',
    'emailondeck.com', 'mailtemp.info', 'tempinbox.com', 'throwam.com',
    'mailinator2.com', 'trashdevil.com', 'trashdevil.de', 'mailin8r.com',
    'spamgob.com', 'spamevader.net', 'spamgourmet.com', 'hmamail.com',
    'crazymailing.com', 'spamstack.net', 'dodgit.com', 'nervmich.net',
}

# ─────────────────────────────────────────────
# VERIFICADOR DE SINTAXIS
# ─────────────────────────────────────────────

EMAIL_REGEX = re.compile(
    r'^(?!.*\.\.)'           # No dobles puntos
    r'(?!.*\.$)'             # No termina en punto
    r'(?!^\.)'               # No empieza en punto
    r'[a-zA-Z0-9]'          # Primer caracter alfanumérico
    r'[a-zA-Z0-9._%+\-]*'  # Parte local
    r'@'                     # Una sola @
    r'[a-zA-Z0-9]'          # Primer caracter del dominio
    r'[a-zA-Z0-9\-]*'       # Dominio
    r'(?:\.[a-zA-Z0-9\-]+)+'  # TLD(s)
    r'$'
)


def check_syntax(email: str) -> Tuple[bool, str]:
    """Verificación avanzada de sintaxis"""
    if not email or not isinstance(email, str):
        return False, "Email vacío o nulo"
    
    email = email.strip().lower()
    
    # Longitud
    if len(email) > 320:
        return False, "Email demasiado largo (máx 320 caracteres)"
    if len(email) < 6:
        return False, "Email demasiado corto"
    
    # Contar arrobas
    at_count = email.count('@')
    if at_count == 0:
        return False, "Falta el símbolo @"
    if at_count > 1:
        return False, f"Múltiples símbolos @ ({at_count} encontrados)"
    
    local, domain = email.rsplit('@', 1)
    
    # Validar parte local
    if len(local) == 0:
        return False, "Parte local vacía"
    if len(local) > 64:
        return False, "Parte local demasiado larga (máx 64 caracteres)"
    
    # Caracteres inválidos
    invalid_chars = set(local) - set('abcdefghijklmnopqrstuvwxyz0123456789._%+-')
    if invalid_chars:
        return False, f"Caracteres inválidos en parte local: {', '.join(invalid_chars)}"
    
    # Dobles puntos
    if '..' in email:
        return False, "Doble punto detectado"
    
    if local.startswith('.') or local.endswith('.'):
        return False, "Parte local no puede empezar o terminar con punto"
    
    # Validar dominio
    if len(domain) == 0:
        return False, "Dominio vacío"
    if len(domain) > 255:
        return False, "Dominio demasiado largo"
    if '.' not in domain:
        return False, "Dominio sin TLD"
    
    parts = domain.split('.')
    if any(len(p) == 0 for p in parts):
        return False, "Dominio con puntos consecutivos"
    
    tld = parts[-1]
    if len(tld) < 2:
        return False, f"TLD inválido: {tld}"
    if not re.match(r'^[a-z]{2,}$', tld):
        return False, f"TLD inválido: {tld}"
    
    # Regex final
    if not EMAIL_REGEX.match(email):
        return False, "Sintaxis de email inválida"
    
    return True, "OK"


# ─────────────────────────────────────────────
# VERIFICADOR DE ROL / SPAMTRAP
# ─────────────────────────────────────────────

def check_role_account(email: str) -> Tuple[bool, str]:
    """Detecta cuentas de rol, spamtraps, postmaster, etc."""
    local = email.split('@')[0].lower()
    
    # Match exacto
    if local in ROLE_ACCOUNTS:
        return True, f"Cuenta de rol detectada: {local}"
    
    # Match parcial para roles comunes
    role_patterns = [
        r'^noreply',r'^no-reply', r'^no_reply',
        r'^donotreply', r'^do-not-reply', r'^bounce',
        r'^postmaster', r'^mailer', r'^spam',
        r'^abuse', r'^admin', r'^support',
        r'^info$', r'^contact$', r'^sales$',
        r'^marketing$', r'^newsletter',
        r'^unsubscribe', r'^webmaster',
        r'^hostmaster', r'^security',
        r'noreply$', r'no-reply$', r'bounce$',
    ]
    
    for pattern in role_patterns:
        if re.search(pattern, local):
            return True, f"Patrón de cuenta de rol: {pattern}"
    
    return False, ""


# ─────────────────────────────────────────────
# VERIFICADOR DNS / MX
# ─────────────────────────────────────────────

def check_mx_records(domain: str, retries: int = 3) -> Tuple[bool, List[str], str]:
    """
    Verifica registros MX con múltiples reintentos.
    Retorna: (tiene_mx, lista_mx, razon)
    """
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 10
    resolver.nameservers = ['8.8.8.8', '1.1.1.1', '8.8.4.4', '9.9.9.9']
    
    last_error = ""
    for attempt in range(retries):
        try:
            mx_records = resolver.resolve(domain, 'MX')
            mx_list = sorted(
                [str(r.exchange).rstrip('.').lower() for r in mx_records],
                key=lambda x: x
            )
            return True, mx_list, "OK"
        except dns.resolver.NXDOMAIN:
            return False, [], "Dominio no existe (NXDOMAIN)"
        except dns.resolver.NoAnswer:
            last_error = "Sin registros MX"
        except dns.resolver.NoNameservers:
            last_error = "Sin servidores DNS disponibles"
        except dns.exception.Timeout:
            last_error = f"Timeout en intento {attempt+1}/{retries}"
            if attempt < retries - 1:
                time.sleep(1)
        except Exception as e:
            last_error = f"Error DNS: {str(e)}"
        
        if attempt < retries - 1:
            time.sleep(0.5)
    
    return False, [], last_error


def check_domain_alive(domain: str) -> Tuple[bool, str]:
    """Verifica si el dominio tiene registros A o NS activos"""
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 8
    resolver.nameservers = ['8.8.8.8', '1.1.1.1']
    
    for record_type in ['A', 'NS']:
        try:
            resolver.resolve(domain, record_type)
            return True, f"Dominio activo ({record_type} encontrado)"
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            continue
        except Exception:
            continue
    
    return False, "Dominio muerto o sin registros activos"


def check_mx_antispam(mx_list: List[str]) -> Tuple[bool, str]:
    """Detecta si los MX son servicios antispam"""
    for mx in mx_list:
        mx_lower = mx.lower()
        for keyword in ANTISPAM_MX_KEYWORDS:
            if keyword.lower() in mx_lower:
                return True, f"Servicio antispam detectado en MX: {keyword} ({mx})"
    return False, ""


def check_mx_parked(mx_list: List[str]) -> Tuple[bool, str]:
    """Detecta si los MX indican dominio parqueado"""
    for mx in mx_list:
        mx_lower = mx.lower()
        for keyword in PARKED_MX_KEYWORDS:
            if re.search(keyword.lower(), mx_lower):
                return True, f"Dominio parqueado detectado en MX: {mx}"
        
        # MX genéricos que indican parking
        if re.match(r'^(mx\d*\.)?[a-z]+-parking\.[a-z]+$', mx_lower):
            return True, f"MX de parking detectado: {mx}"
    
    # Si los MX apuntan a parking conocidos por IP
    parked_mx_patterns = [
        r'sedoparking', r'parklogic', r'parking',
        r'domaincontrol\.com$',  # GoDaddy parking
        r'registrar-servers\.com$',  # Namecheap parking
    ]
    for mx in mx_list:
        for pattern in parked_mx_patterns:
            if re.search(pattern, mx.lower()):
                return True, f"MX asociado a servicio de parking: {mx}"
    
    return False, ""


def check_disposable(domain: str) -> bool:
    """Verifica si el dominio es de email desechable"""
    return domain.lower() in DISPOSABLE_DOMAINS


# ─────────────────────────────────────────────
# VERIFICACIÓN SMTP
# ─────────────────────────────────────────────

def smtp_verify(email: str, mx_list: List[str], timeout: int = 10) -> Tuple[str, str]:
    """
    Intenta verificar el email via SMTP usando RCPT TO.
    Retorna: (status, response_message)
    status: 'valid', 'invalid', 'unknown', 'catch-all'
    """
    if not mx_list:
        return 'unknown', 'Sin registros MX'
    
    test_email = f"verify.test.{int(time.time())}@{email.split('@')[1]}"
    
    for mx in mx_list[:3]:  # Intentar con los primeros 3 MX
        try:
            smtp = smtplib.SMTP(timeout=timeout)
            smtp.connect(mx, 25)
            
            code, msg = smtp.ehlo_or_helo_if_needed()
            
            # Test MAIL FROM
            code, msg = smtp.mail('verify@emailverifier.local')
            if code != 250:
                smtp.quit()
                continue
            
            # Test el email objetivo
            code, msg = smtp.rcpt(email)
            msg_str = msg.decode('utf-8', errors='ignore') if isinstance(msg, bytes) else str(msg)
            
            if code == 250:
                # Verificar si es catch-all probando un email falso
                fake_email = f"zz99nonexistent{int(time.time())}@{email.split('@')[1]}"
                code2, _ = smtp.rcpt(fake_email)
                smtp.quit()
                
                if code2 == 250:
                    return 'catch-all', f'Servidor acepta todos (catch-all): {msg_str}'
                else:
                    return 'valid', f'Email verificado: {msg_str}'
            
            elif code in (550, 551, 553):
                smtp.quit()
                return 'invalid', f'Email rechazado ({code}): {msg_str}'
            
            elif code in (421, 450, 451, 452):
                smtp.quit()
                return 'unknown', f'Servidor no disponible ({code}): {msg_str}'
            
            elif code == 552:
                smtp.quit()
                return 'invalid', f'Mailbox llena/inexistente ({code}): {msg_str}'
            
            else:
                smtp.quit()
                return 'unknown', f'Respuesta inesperada ({code}): {msg_str}'
        
        except smtplib.SMTPConnectError:
            continue
        except smtplib.SMTPServerDisconnected:
            continue
        except socket.timeout:
            continue
        except ConnectionRefusedError:
            continue
        except OSError:
            continue
        except Exception as e:
            continue
    
    return 'unknown', 'No se pudo conectar a los servidores MX'


# ─────────────────────────────────────────────
# VERIFICADOR PRINCIPAL
# ─────────────────────────────────────────────

def verify_email(
    email: str,
    blacklisted_emails: set = None,
    blacklisted_domains: set = None,
    enable_smtp: bool = True,
    dns_retries: int = 3,
    smtp_timeout: int = 10
) -> Dict:
    """
    Verificación completa de un email.
    Retorna diccionario con todos los resultados.
    """
    if blacklisted_emails is None:
        blacklisted_emails = set()
    if blacklisted_domains is None:
        blacklisted_domains = set()
    
    result = {
        'email': email.strip().lower() if email else '',
        'status': 'invalid',
        'reason': '',
        'syntax_valid': False,
        'is_role': False,
        'is_disposable': False,
        'is_parked': False,
        'is_antispam': False,
        'dns_valid': False,
        'mx_records': [],
        'smtp_response': '',
        'score': 0,
        'checks': {}
    }
    
    email = result['email']
    
    # 1. BLACKLIST CHECK
    if email in blacklisted_emails:
        result['status'] = 'blacklisted'
        result['reason'] = 'Email en lista negra personal'
        result['checks']['blacklist'] = 'En blacklist'
        return result
    
    # 2. SYNTAX CHECK
    syntax_ok, syntax_reason = check_syntax(email)
    result['syntax_valid'] = syntax_ok
    result['checks']['syntax'] = syntax_reason
    
    if not syntax_ok:
        result['status'] = 'invalid'
        result['reason'] = syntax_reason
        return result
    
    result['score'] += 20
    local, domain = email.rsplit('@', 1)
    
    # 3. DOMAIN BLACKLIST
    if domain in blacklisted_domains:
        result['status'] = 'blacklisted'
        result['reason'] = f'Dominio en lista negra: {domain}'
        result['checks']['domain_blacklist'] = 'Dominio blacklisted'
        return result
    
    # 4. ROLE/SPAMTRAP CHECK
    is_role, role_reason = check_role_account(email)
    result['is_role'] = is_role
    result['checks']['role'] = role_reason if is_role else 'No es cuenta de rol'
    if is_role:
        result['status'] = 'spamtrap'
        result['reason'] = role_reason
        return result
    
    result['score'] += 15
    
    # 5. DISPOSABLE CHECK
    result['is_disposable'] = check_disposable(domain)
    result['checks']['disposable'] = 'Email desechable' if result['is_disposable'] else 'No desechable'
    if result['is_disposable']:
        result['status'] = 'invalid'
        result['reason'] = 'Dominio de email desechable/temporal'
        return result
    
    result['score'] += 10
    
    # 6. DOMAIN ALIVE CHECK
    domain_alive, alive_reason = check_domain_alive(domain)
    result['checks']['domain_alive'] = alive_reason
    if not domain_alive:
        result['status'] = 'invalid'
        result['reason'] = f'Dominio inactivo/muerto: {alive_reason}'
        return result
    
    result['score'] += 10
    
    # 7. MX RECORDS CHECK (3 intentos)
    has_mx, mx_list, mx_reason = check_mx_records(domain, retries=dns_retries)
    result['dns_valid'] = has_mx
    result['mx_records'] = mx_list
    result['checks']['mx'] = mx_reason if not has_mx else f'MX: {", ".join(mx_list[:2])}'
    
    if not has_mx:
        result['status'] = 'invalid'
        result['reason'] = f'Sin registros MX: {mx_reason}'
        return result
    
    result['score'] += 15
    
    # 8. ANTISPAM MX CHECK
    is_antispam, antispam_reason = check_mx_antispam(mx_list)
    result['is_antispam'] = is_antispam
    result['checks']['antispam'] = antispam_reason if is_antispam else 'MX sin filtros antispam detectados'
    if is_antispam:
        result['status'] = 'risky'
        result['reason'] = antispam_reason
        # No retornamos, seguimos verificando
    
    # 9. PARKED DOMAIN CHECK
    is_parked, parked_reason = check_mx_parked(mx_list)
    result['is_parked'] = is_parked
    result['checks']['parked'] = parked_reason if is_parked else 'Dominio activo (no parqueado)'
    if is_parked:
        result['status'] = 'invalid'
        result['reason'] = parked_reason
        return result
    
    result['score'] += 10
    
    # 10. SMTP VERIFICATION
    if enable_smtp and not is_antispam:
        smtp_status, smtp_msg = smtp_verify(email, mx_list, timeout=smtp_timeout)
        result['smtp_response'] = smtp_msg
        result['checks']['smtp'] = f'{smtp_status}: {smtp_msg}'
        
        if smtp_status == 'valid':
            result['score'] += 20
            result['status'] = 'valid'
            result['reason'] = 'Email verificado exitosamente'
        elif smtp_status == 'invalid':
            result['status'] = 'invalid'
            result['reason'] = f'Email rechazado por servidor: {smtp_msg}'
        elif smtp_status == 'catch-all':
            result['score'] += 10
            result['status'] = 'risky'
            result['reason'] = 'Servidor catch-all (no se puede verificar individualmente)'
        else:
            # unknown - asumimos risky si pasó todas las demás verificaciones
            result['score'] += 10
            if result['status'] != 'risky':
                result['status'] = 'risky'
            result['reason'] = f'No se pudo verificar via SMTP: {smtp_msg}'
    else:
        if result['status'] != 'risky':
            result['status'] = 'risky'
            result['reason'] = 'Verificación SMTP omitida (servidor antispam)'
        result['checks']['smtp'] = 'Omitido'
        result['score'] += 5
    
    # Score final
    result['score'] = min(100, result['score'])
    
    return result


def calculate_score(result: Dict) -> int:
    """Calcula score final 0-100"""
    score = 0
    if result.get('syntax_valid'):
        score += 20
    if not result.get('is_role'):
        score += 15
    if not result.get('is_disposable'):
        score += 10
    if result.get('dns_valid'):
        score += 25
    if result.get('status') == 'valid':
        score += 30
    elif result.get('status') == 'risky':
        score += 15
    return min(100, score)
