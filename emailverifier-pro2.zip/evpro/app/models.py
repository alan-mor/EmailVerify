# models.py
import hashlib
import json
from datetime import datetime

from extensions import db, login_manager
from flask_login import UserMixin


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(120), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    jobs = db.relationship('VerificationJob', backref='user', lazy=True,
                           foreign_keys='VerificationJob.user_id')

    def set_password(self, password):
        self.password_hash = hashlib.sha512(password.encode()).hexdigest()

    def check_password(self, password):
        return self.password_hash == hashlib.sha512(password.encode()).hexdigest()


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class VerificationJob(db.Model):
    __tablename__ = 'verification_jobs'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(20), default='pending')
    celery_task_id = db.Column(db.String(200), nullable=True)
    total_emails = db.Column(db.Integer, default=0)
    processed_emails = db.Column(db.Integer, default=0)
    valid_count = db.Column(db.Integer, default=0)
    invalid_count = db.Column(db.Integer, default=0)
    risky_count = db.Column(db.Integer, default=0)
    duplicate_count = db.Column(db.Integer, default=0)
    spamtrap_count = db.Column(db.Integer, default=0)
    blacklisted_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    started_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)
    input_file = db.Column(db.String(500), nullable=True)
    result_file = db.Column(db.String(500), nullable=True)
    error_message = db.Column(db.Text, nullable=True)
    notify_email = db.Column(db.String(200), nullable=True)
    progress_log = db.Column(db.Text, default='[]')

    def get_progress_pct(self):
        if not self.total_emails:
            return 0
        return round((self.processed_emails / self.total_emails) * 100, 1)

    def add_log(self, message):
        try:
            logs = json.loads(self.progress_log or '[]')
        except Exception:
            logs = []
        logs.append({'time': datetime.utcnow().isoformat(), 'msg': message})
        if len(logs) > 300:
            logs = logs[-300:]
        self.progress_log = json.dumps(logs)


class EmailResult(db.Model):
    __tablename__ = 'email_results'
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('verification_jobs.id'), nullable=False)
    email = db.Column(db.String(320), nullable=False)
    status = db.Column(db.String(20), nullable=True)
    reason = db.Column(db.String(500), nullable=True)
    mx_records = db.Column(db.Text, nullable=True)
    smtp_response = db.Column(db.String(500), nullable=True)
    is_disposable = db.Column(db.Boolean, default=False)
    is_role = db.Column(db.Boolean, default=False)
    is_parked = db.Column(db.Boolean, default=False)
    is_antispam = db.Column(db.Boolean, default=False)
    dns_valid = db.Column(db.Boolean, nullable=True)
    syntax_valid = db.Column(db.Boolean, nullable=True)
    score = db.Column(db.Integer, default=0)
    checked_at = db.Column(db.DateTime, default=datetime.utcnow)


class BlacklistEmail(db.Model):
    __tablename__ = 'blacklist_emails'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    email = db.Column(db.String(320), nullable=False)
    reason = db.Column(db.String(500), nullable=True)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    added_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)


class BlacklistDomain(db.Model):
    __tablename__ = 'blacklist_domains'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    domain = db.Column(db.String(253), nullable=False)
    reason = db.Column(db.String(500), nullable=True)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    added_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)


class AppConfig(db.Model):
    __tablename__ = 'app_config'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @classmethod
    def get(cls, key, default=None):
        row = cls.query.filter_by(key=key).first()
        return row.value if row else default

    @classmethod
    def set(cls, key, value):
        row = cls.query.filter_by(key=key).first()
        if row:
            row.value = value
        else:
            row = cls(key=key, value=value)
            db.session.add(row)
        db.session.commit()
