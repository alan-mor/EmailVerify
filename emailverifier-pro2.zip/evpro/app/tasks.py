# tasks.py
# IMPORTANTE: importa celery y db desde extensions, NO desde app.
# Esto rompe el import circular app -> routes/verify -> tasks -> app.

import csv
import json
import logging
import os
import smtplib
import time
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List

import pandas as pd

from extensions import celery, db
from models import (AppConfig, BlacklistDomain, BlacklistEmail, EmailResult,
                    VerificationJob)
from verifier import verify_email

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def get_blacklists(user_id: int):
    email_bl = set(
        r.email.lower().strip()
        for r in BlacklistEmail.query.filter(
            (BlacklistEmail.user_id == user_id) | (BlacklistEmail.user_id.is_(None))
        ).all()
    )
    domain_bl = set(
        r.domain.lower().strip()
        for r in BlacklistDomain.query.filter(
            (BlacklistDomain.user_id == user_id) | (BlacklistDomain.user_id.is_(None))
        ).all()
    )
    return email_bl, domain_bl


def parse_email_file(filepath: str) -> List[str]:
    ext = os.path.splitext(filepath)[1].lower()
    emails = []

    if ext == '.txt':
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                for part in line.strip().split(','):
                    part = part.strip().strip('"').strip("'")
                    if '@' in part and '.' in part:
                        emails.append(part)

    elif ext == '.csv':
        for enc in ('utf-8', 'latin-1', 'cp1252'):
            try:
                df = pd.read_csv(filepath, header=None, dtype=str,
                                 encoding=enc, on_bad_lines='skip')
                break
            except Exception:
                continue
        else:
            return emails
        for col in df.columns:
            for val in df[col].dropna().astype(str):
                val = val.strip()
                if '@' in val and '.' in val:
                    emails.append(val)

    elif ext in ('.xlsx', '.xls'):
        try:
            df = pd.read_excel(filepath, header=None, dtype=str)
            for col in df.columns:
                for val in df[col].dropna().astype(str):
                    val = val.strip()
                    if '@' in val and '.' in val:
                        emails.append(val)
        except Exception as e:
            logger.error(f'Error leyendo Excel: {e}')

    return emails


def deduplicate(emails: List[str]):
    seen = set()
    unique = []
    dupes = 0
    for e in emails:
        n = e.strip().lower()
        if n and n not in seen:
            seen.add(n)
            unique.append(n)
        elif n:
            dupes += 1
    return unique, dupes


def send_completion_email(job):
    if not job.notify_email:
        return
    smtp_host = AppConfig.get('smtp_host', '')
    smtp_port = int(AppConfig.get('smtp_port', '587') or '587')
    smtp_user = AppConfig.get('smtp_user', '')
    smtp_pass = AppConfig.get('smtp_pass', '')
    smtp_from = AppConfig.get('smtp_from', '') or smtp_user
    smtp_ssl  = AppConfig.get('smtp_ssl', 'tls')
    if not smtp_host or not smtp_user:
        return
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f'✅ Verificación completada: {job.name}'
        msg['From'] = smtp_from
        msg['To'] = job.notify_email
        html = f"""<html><body style="font-family:Arial,sans-serif">
        <h2>✅ Verificación completada: {job.name}</h2>
        <table border="1" cellpadding="8" cellspacing="0">
          <tr><td>Total</td><td>{job.total_emails}</td></tr>
          <tr><td>✅ Válidos</td><td>{job.valid_count}</td></tr>
          <tr><td>⚠️ Riesgosos</td><td>{job.risky_count}</td></tr>
          <tr><td>❌ Inválidos</td><td>{job.invalid_count}</td></tr>
          <tr><td>🔁 Duplicados</td><td>{job.duplicate_count}</td></tr>
          <tr><td>🚫 Spamtraps</td><td>{job.spamtrap_count}</td></tr>
          <tr><td>⛔ Blacklisted</td><td>{job.blacklisted_count}</td></tr>
        </table>
        <p>Descarga los resultados desde el panel de control.</p>
        </body></html>"""
        msg.attach(MIMEText(html, 'html'))
        if smtp_ssl == 'ssl':
            s = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=30)
        else:
            s = smtplib.SMTP(smtp_host, smtp_port, timeout=30)
            if smtp_ssl == 'tls':
                s.starttls()
        if smtp_user and smtp_pass:
            s.login(smtp_user, smtp_pass)
        s.sendmail(smtp_from, [job.notify_email], msg.as_string())
        s.quit()
    except Exception as e:
        logger.error(f'Error enviando notificación: {e}')


def save_results_csv(job, results_folder: str) -> str:
    filename = f'job_{job.id}_{int(time.time())}.csv'
    filepath = os.path.join(results_folder, filename)
    os.makedirs(results_folder, exist_ok=True)
    results = EmailResult.query.filter_by(job_id=job.id).all()
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Email', 'Estado', 'Razón', 'Score', 'Sintaxis OK',
                    'Es Rol/Spamtrap', 'Es Desechable', 'Es Parqueado',
                    'Es Antispam', 'DNS Válido', 'Registros MX',
                    'Respuesta SMTP', 'Verificado'])
        for r in results:
            w.writerow([
                r.email, r.status, r.reason or '', r.score,
                'Sí' if r.syntax_valid else 'No',
                'Sí' if r.is_role else 'No',
                'Sí' if r.is_disposable else 'No',
                'Sí' if r.is_parked else 'No',
                'Sí' if r.is_antispam else 'No',
                'Sí' if r.dns_valid else 'No',
                r.mx_records or '',
                r.smtp_response or '',
                r.checked_at.strftime('%Y-%m-%d %H:%M:%S') if r.checked_at else '',
            ])
    return filename


# ─────────────────────────────────────────────
# Tarea principal Celery
# ─────────────────────────────────────────────

@celery.task(bind=True, name='tasks.run_verification')
def run_verification(self, job_id: int):
    job = VerificationJob.query.get(job_id)
    if not job:
        return {'error': f'Job {job_id} no encontrado'}

    results_folder = os.getenv('RESULTS_FOLDER', 'results')
    enable_smtp = (AppConfig.get('enable_smtp_verify', 'true') or 'true').lower() == 'true'
    dns_retries  = int(AppConfig.get('dns_retries', '3') or '3')
    smtp_timeout = int(AppConfig.get('smtp_timeout', '10') or '10')

    try:
        job.status = 'running'
        job.started_at = datetime.utcnow()
        job.add_log('🚀 Iniciando verificación...')
        db.session.commit()

        # Leer archivo
        job.add_log('📂 Leyendo archivo...')
        db.session.commit()
        raw_emails = parse_email_file(job.input_file)
        job.add_log(f'📧 {len(raw_emails)} emails encontrados')
        db.session.commit()

        # Deduplicar
        unique_emails, dupe_count = deduplicate(raw_emails)
        job.duplicate_count = dupe_count
        job.total_emails = len(unique_emails) + dupe_count
        job.add_log(f'🔄 {dupe_count} duplicados eliminados — {len(unique_emails)} únicos a verificar')
        db.session.commit()

        # Guardar duplicados
        if dupe_count > 0:
            seen = set()
            for raw in [e.strip().lower() for e in raw_emails if e.strip()]:
                if raw in seen:
                    db.session.add(EmailResult(
                        job_id=job_id, email=raw,
                        status='duplicate', reason='Email duplicado',
                        syntax_valid=True, score=0
                    ))
                else:
                    seen.add(raw)
            db.session.commit()

        # Blacklists
        email_bl, domain_bl = get_blacklists(job.user_id)
        job.add_log(f'⛔ Blacklists: {len(email_bl)} emails, {len(domain_bl)} dominios')
        db.session.commit()

        valid_c = invalid_c = risky_c = spam_c = bl_c = 0
        BATCH = 50

        for i, email in enumerate(unique_emails):
            try:
                res = verify_email(
                    email,
                    blacklisted_emails=email_bl,
                    blacklisted_domains=domain_bl,
                    enable_smtp=enable_smtp,
                    dns_retries=dns_retries,
                    smtp_timeout=smtp_timeout,
                )
                s = res['status']
                if s == 'valid':       valid_c += 1
                elif s == 'invalid':   invalid_c += 1
                elif s == 'risky':     risky_c += 1
                elif s == 'spamtrap':  spam_c += 1
                elif s == 'blacklisted': bl_c += 1

                mx_str = ', '.join(res.get('mx_records', []))[:500]
                db.session.add(EmailResult(
                    job_id=job_id,
                    email=res['email'],
                    status=s,
                    reason=(res.get('reason') or '')[:500],
                    syntax_valid=res.get('syntax_valid', False),
                    is_role=res.get('is_role', False),
                    is_disposable=res.get('is_disposable', False),
                    is_parked=res.get('is_parked', False),
                    is_antispam=res.get('is_antispam', False),
                    dns_valid=res.get('dns_valid'),
                    mx_records=mx_str,
                    smtp_response=(res.get('smtp_response') or '')[:500],
                    score=res.get('score', 0),
                ))

                if (i + 1) % BATCH == 0:
                    job.processed_emails = i + 1
                    job.valid_count = valid_c
                    job.invalid_count = invalid_c
                    job.risky_count = risky_c
                    job.spamtrap_count = spam_c
                    job.blacklisted_count = bl_c
                    pct = round(((i + 1) / len(unique_emails)) * 100, 1)
                    job.add_log(
                        f'⚡ {i+1}/{len(unique_emails)} ({pct}%) '
                        f'✅{valid_c} ❌{invalid_c} ⚠️{risky_c} 🚫{spam_c}'
                    )
                    db.session.commit()

            except Exception as e:
                logger.error(f'Error en {email}: {e}')
                db.session.add(EmailResult(
                    job_id=job_id, email=email,
                    status='invalid',
                    reason=f'Error interno: {str(e)[:200]}',
                    score=0
                ))

        # Commit final de resultados
        job.processed_emails = len(unique_emails)
        job.valid_count = valid_c
        job.invalid_count = invalid_c
        job.risky_count = risky_c
        job.spamtrap_count = spam_c
        job.blacklisted_count = bl_c
        job.status = 'completed'
        job.completed_at = datetime.utcnow()
        job.add_log('💾 Generando CSV de resultados...')
        db.session.commit()

        result_file = save_results_csv(job, results_folder)
        job.result_file = result_file
        job.add_log(
            f'✅ ¡Completado! '
            f'✅{valid_c} válidos | ❌{invalid_c} inválidos | '
            f'⚠️{risky_c} riesgosos | 🚫{spam_c} spamtraps | '
            f'🔁{dupe_count} duplicados'
        )
        db.session.commit()

        send_completion_email(job)

        return {
            'status': 'completed', 'job_id': job_id,
            'valid': valid_c, 'invalid': invalid_c,
            'risky': risky_c, 'spamtrap': spam_c,
            'blacklisted': bl_c, 'duplicates': dupe_count,
        }

    except Exception as e:
        logger.error(f'Error fatal job {job_id}: {e}')
        try:
            job = VerificationJob.query.get(job_id)
            if job:
                job.status = 'failed'
                job.error_message = str(e)[:500]
                job.add_log(f'❌ Error fatal: {e}')
                db.session.commit()
        except Exception:
            pass
        raise
