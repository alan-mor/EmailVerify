# extensions.py
# Objetos compartidos declarados aquí para evitar imports circulares.
# Ningún otro módulo del proyecto debe crear db, login_manager o celery.

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from celery import Celery

db = SQLAlchemy()
login_manager = LoginManager()

# Celery se crea aquí con valores por defecto.
# La URL real se inyecta en create_app() vía celery.conf.update()
celery = Celery()
