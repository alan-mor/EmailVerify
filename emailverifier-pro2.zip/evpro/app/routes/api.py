# routes/api.py
import json
import smtplib
from flask import Blueprint, jsonify, request, abort
from flask_login import login_required, current_user
from extensions import db
from models import VerificationJob

api_bp = Blueprint('api', __name__)


@api_bp.route('/job/<int:job_id>/status')
@login_required
def job_status(job_id):
    job = VerificationJob.query.get_or_404(job_id)
    if not current_user.is_admin and job.user_id != current_user.id:
        abort(403)
    try:
        logs = json.loads(job.progress_log or '[]')
    except Exception:
        logs = []
    return jsonify({
        'id': job.id,
        'status': job.status,
        'progress': job.get_progress_pct(),
        'processed': job.processed_emails,
        'total': job.total_emails,
        'valid': job.valid_count,
        'invalid': job.invalid_count,
        'risky': job.risky_count,
        'spamtrap': job.spamtrap_count,
        'blacklisted': job.blacklisted_count,
        'duplicate': job.duplicate_count,
        'logs': logs[-20:],
        'result_file': job.result_file,
        'error': job.error_message,
    })


@api_bp.route('/test-smtp', methods=['POST'])
@login_required
def test_smtp():
    if not current_user.is_admin:
        abort(403)
    data = request.get_json() or {}
    host = data.get('smtp_host', '').strip()
    port = int(data.get('smtp_port', 587) or 587)
    user = data.get('smtp_user', '').strip()
    pwd  = data.get('smtp_pass', '').strip()
    ssl  = data.get('smtp_ssl', 'tls')
    if not host:
        return jsonify({'ok': False, 'message': 'Servidor SMTP vacío'})
    try:
        if ssl == 'ssl':
            s = smtplib.SMTP_SSL(host, port, timeout=10)
        else:
            s = smtplib.SMTP(host, port, timeout=10)
            if ssl == 'tls':
                s.starttls()
        if user and pwd:
            s.login(user, pwd)
        s.quit()
        return jsonify({'ok': True, 'message': '✅ Conexión SMTP exitosa'})
    except Exception as e:
        return jsonify({'ok': False, 'message': str(e)})


@api_bp.route('/job/<int:job_id>/cancel', methods=['POST'])
@login_required
def cancel_job(job_id):
    job = VerificationJob.query.get_or_404(job_id)
    if not current_user.is_admin and job.user_id != current_user.id:
        abort(403)
    if job.status in ('pending', 'running'):
        from extensions import celery
        if job.celery_task_id:
            celery.control.revoke(job.celery_task_id, terminate=True)
        job.status = 'failed'
        job.error_message = 'Cancelado por el usuario'
        db.session.commit()
    return jsonify({'ok': True})
