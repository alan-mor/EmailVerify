# init_db.py — ejecutar una sola vez para inicializar la base de datos
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app
from extensions import db
from models import User, AppConfig


def init():
    with app.app_context():
        db.create_all()
        print('✅ Tablas creadas')

        # Usuario admin inicial
        if not User.query.filter_by(username='alanmor').first():
            admin = User(username='alanmor', is_admin=True, is_active=True)
            # Hash SHA-512 preestablecido (NO se cambia aquí)
            admin.password_hash = (
                '567ee3dadc9d4b1ea71ea34885129cd890fdf0dc6f722beee378481'
                'fb0352166fa571013c89605403f1316a60331dbd1b2b03e9fd37f5b'
                'e4490d885d43839a96'
            )
            db.session.add(admin)
            db.session.commit()
            print('✅ Usuario administrador creado')
        else:
            print('ℹ️  Usuario administrador ya existe')

        # Configuración por defecto
        defaults = {
            'smtp_host': '', 'smtp_port': '587', 'smtp_user': '',
            'smtp_pass': '', 'smtp_from': '', 'smtp_ssl': 'tls',
            'enable_smtp_verify': 'true', 'dns_retries': '3',
            'smtp_timeout': '10', 'max_workers': '10',
            'site_name': 'EmailVerifier Pro', 'site_url': '',
        }
        for k, v in defaults.items():
            if AppConfig.get(k) is None:
                AppConfig.set(k, v)
        print('✅ Configuración inicial lista')
        print('\n🚀 Base de datos inicializada correctamente')


if __name__ == '__main__':
    init()
