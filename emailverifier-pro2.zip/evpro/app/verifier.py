# verifier.py — Motor de verificación de emails
import re
import socket
import smtplib
import time
import logging
from typing import Dict, List, Tuple

import dns.resolver
import dns.exception

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# LISTAS
# ─────────────────────────────────────────────

ROLE_ACCOUNTS = {
    'noreply','no-reply','no_reply','donotreply','do-not-reply','do_not_reply',
    'postmaster','mailer-daemon','mailer_daemon','mailerdaemon',
    'antispam','anti-spam','anti_spam','spam','spamtrap','spam-trap',
    'abuse','security','hostmaster','webmaster','www','uucp','ftp',
    'root','operator','daemon','bin','sys','nobody','null','devnull',
    'blackhole','bounce','bounces','ndr','return','returns',
    'unsubscribe','subscribe','newsletter','notifications','notification',
    'alerts','alert','info','information','help','helpdesk','support',
    'admin','administrator','sysadmin','contact','sales','marketing',
    'billing','invoices','invoice','accounts','account','service',
    'services','team','office','staff','mail','email','mailbox','inbox',
    'test','testing','demo','example','sample','anonymous','anon',
    'delete','deleted','removed','invalid','unknown','undisclosed',
    'recipient','recipients','feedback','reply','replies','autoresponder',
    'auto-responder','auto_responder','vacation','out-of-office',
    'outofoffice','ops','operations','legal','hr','humanresources',
    'it','tech','techsupport','register','registration','confirm',
    'confirmation','verify','verification','activate','activation',
    'password','reset','welcome','system','automated','automatic',
    'robot','bot','crawler','spider','network','monitoring','monitor',
    'report','reports','analytics','stats','statistics','press','media',
    'pr','publicrelations','partnerships','partner','vendor','suppliers',
    'supplier','procurement','orders','order','shipping','delivery',
    'logistics','warehouse','store','shop','payment','payments','finance',
    'financial','tax','vat','compliance','privacy','gdpr','dpo',
    'catch-all','catchall','dns','smtp','imap','pop3','fax','calendar',
    'scheduler','cron','jobs','job','careers','career','hiring',
    'recruitment','recruiter','hostmaster',
}

ANTISPAM_MX_KEYWORDS = [
    'ik2','spamexperts','spamhero','spamsoap','antispamcloud',
    'mxlogic','postini','messagelabs','symanteccloud','proofpoint',
    'pphosted','barracuda','cudamail','reflexion','appriver','exclaimer',
    'mimecast','hornetsecurity','mailprotect','mailscanner','spamfilter',
    'antispam','spam-filter','maildefense','mailcleaner','mailwasher',
    'mailprotector','cleanmx','mailpure','spamblocker','mailguard',
    'mailsecurity','mailgate','mailarmor','spamtitan','securence',
    'zixmail','zixcorp','trustifi','avanan','abnormalsecurity',
    'ironscales','cofense','agari','vade','vadesecure','mailroute',
    'mailhop','returnpath','validity','spamcop','cloudmark',
]

PARKED_MX_PATTERNS = [
    r'sedoparking', r'parkingcrew', r'bodis', r'above\.com',
    r'hugedomains', r'domainmonster', r'parking', r'sinkhole',
    r'afternic', r'dan\.com', r'uniregistry', r'sedo\.com',
    r'domaincontrol\.com',      # GoDaddy parking
    r'registrar-servers\.com',  # Namecheap parking
]

DISPOSABLE_DOMAINS = {
    'mailinator.com','guerrillamail.com','tempmail.com','yopmail.com',
    'sharklasers.com','guerrillamail.info','guerrillamail.biz',
    'guerrillamail.de','guerrillamail.net','guerrillamail.org',
    'spam4.me','trashmail.com','trashmail.me','trashmail.net',
    'dispostable.com','mailnull.com','spamgourmet.com','spamgourmet.net',
    'spamgourmet.org','10minutemail.com','10minutemail.net',
    '10minutemail.org','tempinbox.com','tempr.email','discard.email',
    'maildrop.cc','mailnesia.com','mailrock.biz','getnada.com',
    'trashmail.at','trashmail.io','trashmail.xyz','wegwerfmail.de',
    'tempmail.ninja','tempmail.plus','fakemail.net','emailondeck.com',
    'mailtemp.info','throwam.com','mailin8r.com','dodgit.com',
    'hmamail.com','spamstack.net','mohmal.com','safetymail.info',
    'mailexpire.com','jetable.fr.nf',
}

# Regex de sintaxis estricto
_EMAIL_RE = re.compile(
    r'^[a-zA-Z0-9][a-zA-Z0-9._%+\-]{0,63}'
    r'@'
    r'[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9]?'
    r'(?:\.[a-zA-Z]{2,})+$'
)


# ─────────────────────────────────────────────
# CHECKS
# ─────────────────────────────────────────────

def check_syntax(email: str) -> Tuple[bool, str]:
    if not email or not isinstance(email, str):
        return False, 'Email vacío'
    e = email.strip().lower()
    if len(e) > 320:
        return False, 'Email demasiado largo'
    if len(e) < 6:
        return False, 'Email demasiado corto'
    if e.count('@') == 0:
        return False, 'Falta @'
    if e.count('@') > 1:
        return False, f'Múltiples @ ({e.count("@")} encontrados)'
    local, domain = e.rsplit('@', 1)
    if not local:
        return False, 'Parte local vacía'
    if len(local) > 64:
        return False, 'Parte local demasiado larga'
    if '..' in e:
        return False, 'Doble punto (..) detectado'
    if local.startswith('.') or local.endswith('.'):
        return False, 'Parte local no puede empezar/terminar con punto'
    if '.' not in domain:
        return False, 'Dominio sin TLD'
    if not _EMAIL_RE.match(e):
        return False, 'Sintaxis inválida'
    return True, 'OK'


def check_role(email: str) -> Tuple[bool, str]:
    local = email.split('@')[0].lower()
    if local in ROLE_ACCOUNTS:
        return True, f'Cuenta de rol: {local}'
    patterns = [
        r'^noreply', r'^no-reply', r'^no_reply', r'^donotreply',
        r'^bounce', r'^postmaster', r'^mailer', r'^abuse',
        r'^newsletter', r'^unsubscribe', r'^webmaster',
        r'noreply$', r'no-reply$', r'bounce$',
    ]
    for p in patterns:
        if re.search(p, local):
            return True, f'Patrón de rol detectado: {p}'
    return False, ''


def check_disposable(domain: str) -> bool:
    return domain.lower() in DISPOSABLE_DOMAINS


def check_domain_alive(domain: str) -> Tuple[bool, str]:
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 8
    resolver.nameservers = ['8.8.8.8', '1.1.1.1']
    for rtype in ('A', 'NS', 'MX'):
        try:
            resolver.resolve(domain, rtype)
            return True, f'Dominio activo ({rtype})'
        except (dns.resolver.NXDOMAIN,):
            return False, 'Dominio no existe (NXDOMAIN)'
        except Exception:
            continue
    return False, 'Sin registros DNS activos'


def check_mx(domain: str, retries: int = 3) -> Tuple[bool, List[str], str]:
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 10
    resolver.nameservers = ['8.8.8.8', '1.1.1.1', '8.8.4.4', '9.9.9.9']
    last_err = 'Sin registros MX'
    for attempt in range(retries):
        try:
            answers = resolver.resolve(domain, 'MX')
            mx_list = sorted(
                [str(r.exchange).rstrip('.').lower() for r in answers]
            )
            return True, mx_list, 'OK'
        except dns.resolver.NXDOMAIN:
            return False, [], 'Dominio inexistente'
        except dns.resolver.NoAnswer:
            last_err = 'Sin registros MX'
            break
        except dns.exception.Timeout:
            last_err = f'Timeout DNS (intento {attempt+1})'
            time.sleep(0.5)
        except Exception as ex:
            last_err = str(ex)
            time.sleep(0.3)
    return False, [], last_err


def check_mx_antispam(mx_list: List[str]) -> Tuple[bool, str]:
    for mx in mx_list:
        for kw in ANTISPAM_MX_KEYWORDS:
            if kw in mx.lower():
                return True, f'Antispam en MX: {kw} ({mx})'
    return False, ''


def check_mx_parked(mx_list: List[str]) -> Tuple[bool, str]:
    for mx in mx_list:
        for pat in PARKED_MX_PATTERNS:
            if re.search(pat, mx.lower()):
                return True, f'Dominio parqueado detectado: {mx}'
    return False, ''


def smtp_verify(email: str, mx_list: List[str], timeout: int = 10) -> Tuple[str, str]:
    """
    Retorna (status, mensaje)
    status: 'valid' | 'invalid' | 'catch-all' | 'unknown'
    """
    domain = email.split('@')[1]
    for mx in mx_list[:3]:
        try:
            with smtplib.SMTP(timeout=timeout) as smtp:
                smtp.connect(mx, 25)
                smtp.ehlo_or_helo_if_needed()
                code, _ = smtp.mail('probe@emailverifier.local')
                if code != 250:
                    continue
                code, msg = smtp.rcpt(email)
                msg_str = msg.decode('utf-8', errors='ignore') if isinstance(msg, bytes) else str(msg)

                if code == 250:
                    # Detectar catch-all
                    fake = f'zzz_fake_{int(time.time())}@{domain}'
                    code2, _ = smtp.rcpt(fake)
                    if code2 == 250:
                        return 'catch-all', 'Servidor catch-all detectado'
                    return 'valid', f'Aceptado (250): {msg_str}'

                if code in (550, 551, 553, 554):
                    return 'invalid', f'Rechazado ({code}): {msg_str}'
                if code in (421, 450, 451, 452):
                    return 'unknown', f'Temporalmente no disponible ({code}): {msg_str}'
                return 'unknown', f'Respuesta inesperada ({code}): {msg_str}'

        except (smtplib.SMTPConnectError, ConnectionRefusedError,
                socket.timeout, OSError, smtplib.SMTPServerDisconnected):
            continue
        except Exception:
            continue

    return 'unknown', 'No se pudo conectar a los servidores MX'


# ─────────────────────────────────────────────
# VERIFICADOR PRINCIPAL
# ─────────────────────────────────────────────

def verify_email(
    email: str,
    blacklisted_emails=None,
    blacklisted_domains=None,
    enable_smtp: bool = True,
    dns_retries: int = 3,
    smtp_timeout: int = 10,
) -> Dict:
    if blacklisted_emails is None:
        blacklisted_emails = set()
    if blacklisted_domains is None:
        blacklisted_domains = set()

    result = {
        'email': email.strip().lower() if email else '',
        'status': 'invalid',
        'reason': '',
        'syntax_valid': False,
        'is_role': False,
        'is_disposable': False,
        'is_parked': False,
        'is_antispam': False,
        'dns_valid': False,
        'mx_records': [],
        'smtp_response': '',
        'score': 0,
    }
    e = result['email']

    # 1. Blacklist email
    if e in blacklisted_emails:
        result.update(status='blacklisted', reason='Email en lista negra')
        return result

    # 2. Sintaxis
    ok, reason = check_syntax(e)
    result['syntax_valid'] = ok
    if not ok:
        result['reason'] = reason
        return result
    result['score'] += 20

    local, domain = e.rsplit('@', 1)

    # 3. Blacklist dominio
    if domain in blacklisted_domains:
        result.update(status='blacklisted', reason=f'Dominio en lista negra: {domain}')
        return result

    # 4. Rol / spamtrap
    is_role, role_reason = check_role(e)
    result['is_role'] = is_role
    if is_role:
        result.update(status='spamtrap', reason=role_reason)
        return result
    result['score'] += 15

    # 5. Desechable
    result['is_disposable'] = check_disposable(domain)
    if result['is_disposable']:
        result.update(status='invalid', reason='Dominio de email desechable')
        return result
    result['score'] += 10

    # 6. Dominio vivo
    alive, alive_reason = check_domain_alive(domain)
    if not alive:
        result.update(status='invalid', reason=f'Dominio muerto: {alive_reason}')
        return result
    result['score'] += 10

    # 7. MX (con reintentos)
    has_mx, mx_list, mx_reason = check_mx(domain, retries=dns_retries)
    result['dns_valid'] = has_mx
    result['mx_records'] = mx_list
    if not has_mx:
        result.update(status='invalid', reason=f'Sin registros MX: {mx_reason}')
        return result
    result['score'] += 15

    # 8. MX antispam
    is_as, as_reason = check_mx_antispam(mx_list)
    result['is_antispam'] = is_as
    if is_as:
        result.update(status='risky', reason=as_reason)
        # No retornamos — seguimos para dar más info

    # 9. MX parqueado
    is_pk, pk_reason = check_mx_parked(mx_list)
    result['is_parked'] = is_pk
    if is_pk:
        result.update(status='invalid', reason=pk_reason)
        return result
    result['score'] += 10

    # 10. SMTP
    if enable_smtp and not is_as:
        smtp_status, smtp_msg = smtp_verify(e, mx_list, timeout=smtp_timeout)
        result['smtp_response'] = smtp_msg

        if smtp_status == 'valid':
            result['score'] += 20
            result.update(status='valid', reason='Verificado por SMTP')
        elif smtp_status == 'invalid':
            result.update(status='invalid', reason=f'Rechazado SMTP: {smtp_msg}')
        elif smtp_status == 'catch-all':
            result['score'] += 10
            result.update(status='risky', reason='Servidor catch-all (no verificable individualmente)')
        else:
            result['score'] += 5
            if result['status'] != 'risky':
                result.update(status='risky', reason=f'SMTP no concluyente: {smtp_msg}')
    else:
        result['score'] += 5
        if result['status'] not in ('risky', 'invalid'):
            result.update(status='risky', reason='SMTP omitido (servidor antispam detectado)')

    result['score'] = min(100, result['score'])
    return result
