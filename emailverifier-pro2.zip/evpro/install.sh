#!/bin/bash
# EmailVerifier Pro — Instalador para Ubuntu Server
# Uso: sudo bash install.sh
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

INSTALL_DIR="/opt/emailverifier"
APP_USER="www-data"
DB_NAME="emailverifier"
DB_USER="evdbuser"
DB_PASS=$(openssl rand -base64 32 | tr -d '/+=' | head -c 24)
SECRET_KEY=$(openssl rand -hex 32)

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗] ERROR: $1${NC}"; exit 1; }
step() { echo -e "\n${CYAN}${BOLD}[$1]${NC} $2"; }

echo -e "${CYAN}${BOLD}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║      EmailVerifier Pro — Instalador v2.0             ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"

[ "$EUID" -ne 0 ] && err "Ejecutar como root: sudo bash install.sh"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_SRC="${SCRIPT_DIR}/app"
[ -d "${APP_SRC}" ] || err "No se encontró el directorio 'app/' junto a install.sh"

# ── 1. Sistema ──────────────────────────────────────────────
step "1/10" "Instalando dependencias del sistema..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq \
  python3 python3-pip python3-venv python3-dev \
  postgresql postgresql-contrib \
  redis-server nginx supervisor \
  curl wget dnsutils build-essential \
  libpq-dev unzip ufw
log "Dependencias instaladas"

# ── 2. PostgreSQL ────────────────────────────────────────────
step "2/10" "Configurando PostgreSQL..."
systemctl start postgresql
systemctl enable postgresql
sudo -u postgres psql -c "DROP DATABASE IF EXISTS ${DB_NAME};" 2>/dev/null || true
sudo -u postgres psql -c "DROP USER IF EXISTS ${DB_USER};"      2>/dev/null || true
sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"
sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"
log "PostgreSQL configurado"

# ── 3. Directorios ───────────────────────────────────────────
step "3/10" "Creando directorios..."
mkdir -p ${INSTALL_DIR}/{uploads,results,logs,blacklists,static,templates/admin,routes}
log "Directorios creados en ${INSTALL_DIR}"

# ── 4. Archivos ──────────────────────────────────────────────
step "4/10" "Copiando archivos..."
cp -r ${APP_SRC}/* ${INSTALL_DIR}/
log "Archivos copiados"

# ── 5. Python venv ───────────────────────────────────────────
step "5/10" "Configurando entorno Python..."
python3 -m venv ${INSTALL_DIR}/venv
source ${INSTALL_DIR}/venv/bin/activate
pip install --quiet --upgrade pip setuptools wheel
pip install --quiet -r ${INSTALL_DIR}/requirements.txt
log "Entorno Python listo"

# ── 6. .env + init DB ───────────────────────────────────────
step "6/10" "Configurando base de datos..."
cat > ${INSTALL_DIR}/.env << EOF
SECRET_KEY=${SECRET_KEY}
DATABASE_URL=postgresql://${DB_USER}:${DB_PASS}@localhost/${DB_NAME}
REDIS_URL=redis://localhost:6379/0
UPLOAD_FOLDER=${INSTALL_DIR}/uploads
RESULTS_FOLDER=${INSTALL_DIR}/results
BLACKLIST_FOLDER=${INSTALL_DIR}/blacklists
LOG_FOLDER=${INSTALL_DIR}/logs
FLASK_ENV=production
EOF

cd ${INSTALL_DIR}
source venv/bin/activate
python3 init_db.py || err "Falló init_db.py — revisa los logs"
log "Base de datos inicializada"

# ── 7. Permisos ──────────────────────────────────────────────
step "7/10" "Configurando permisos..."
chown -R ${APP_USER}:${APP_USER} ${INSTALL_DIR}
chmod -R 755 ${INSTALL_DIR}
chmod 600 ${INSTALL_DIR}/.env
chmod 700 ${INSTALL_DIR}/uploads ${INSTALL_DIR}/results
log "Permisos configurados"

# ── 8. Nginx ─────────────────────────────────────────────────
step "8/10" "Configurando Nginx..."
SERVER_IP=$(hostname -I | awk '{print $1}')
cat > /etc/nginx/sites-available/emailverifier << NGINXEOF
server {
    listen 80 default_server;
    server_name _;
    client_max_body_size 500M;
    client_body_timeout 300s;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 300s;
        proxy_buffering off;
    }

    location /static/ {
        alias ${INSTALL_DIR}/static/;
        expires 7d;
    }

    access_log /var/log/nginx/emailverifier.log;
    error_log  /var/log/nginx/emailverifier_err.log;
}
NGINXEOF
ln -sf /etc/nginx/sites-available/emailverifier /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t || err "Configuración de Nginx inválida"
log "Nginx configurado"

# ── 9. Supervisor ────────────────────────────────────────────
step "9/10" "Configurando Supervisor..."
cat > /etc/supervisor/conf.d/emailverifier-web.conf << EOF
[program:emailverifier-web]
command=${INSTALL_DIR}/venv/bin/gunicorn \
    --workers 4 \
    --worker-class eventlet \
    --bind 127.0.0.1:5000 \
    --timeout 300 \
    --access-logfile ${INSTALL_DIR}/logs/access.log \
    --error-logfile ${INSTALL_DIR}/logs/error.log \
    app:app
directory=${INSTALL_DIR}
user=${APP_USER}
autostart=true
autorestart=true
startsecs=10
startretries=5
redirect_stderr=true
stdout_logfile=${INSTALL_DIR}/logs/gunicorn.log
environment=PYTHONUNBUFFERED="1"
EOF

cat > /etc/supervisor/conf.d/emailverifier-worker.conf << EOF
[program:emailverifier-worker]
command=${INSTALL_DIR}/venv/bin/celery \
    -A tasks \
    worker \
    --loglevel=info \
    --concurrency=4 \
    --logfile=${INSTALL_DIR}/logs/celery.log
directory=${INSTALL_DIR}
user=${APP_USER}
autostart=true
autorestart=true
startsecs=10
startretries=5
redirect_stderr=true
stdout_logfile=${INSTALL_DIR}/logs/celery_sup.log
environment=PYTHONUNBUFFERED="1"
EOF
log "Supervisor configurado"

# ── 10. Iniciar servicios ────────────────────────────────────
step "10/10" "Iniciando servicios..."
systemctl enable redis-server && systemctl restart redis-server
systemctl enable supervisor  && systemctl restart supervisor
systemctl enable nginx       && systemctl restart nginx

sleep 4
supervisorctl reread
supervisorctl update
sleep 2
supervisorctl start emailverifier-web    2>/dev/null || true
supervisorctl start emailverifier-worker 2>/dev/null || true
sleep 5

WEB=$(supervisorctl status emailverifier-web    2>/dev/null | grep -c RUNNING || echo 0)
WRK=$(supervisorctl status emailverifier-worker 2>/dev/null | grep -c RUNNING || echo 0)

echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║        ✅  INSTALACIÓN COMPLETADA                        ║${NC}"
echo -e "${GREEN}${BOLD}╠══════════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}${BOLD}║${NC}  🌐 URL:     ${CYAN}http://${SERVER_IP}${NC}"
echo -e "${GREEN}${BOLD}║${NC}  📁 Ruta:    ${INSTALL_DIR}"
echo -e "${GREEN}${BOLD}║${NC}  Web App:  $([ "$WEB" = "1" ] && echo "${GREEN}✅ ACTIVO${NC}" || echo "${RED}❌ ver logs${NC}")"
echo -e "${GREEN}${BOLD}║${NC}  Worker:   $([ "$WRK" = "1" ] && echo "${GREEN}✅ ACTIVO${NC}" || echo "${RED}❌ ver logs${NC}")"
echo -e "${GREEN}${BOLD}╠══════════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}${BOLD}║${NC}  ${YELLOW}Comandos útiles:${NC}"
echo -e "${GREEN}${BOLD}║${NC}  supervisorctl status"
echo -e "${GREEN}${BOLD}║${NC}  tail -f ${INSTALL_DIR}/logs/gunicorn.log"
echo -e "${GREEN}${BOLD}║${NC}  tail -f ${INSTALL_DIR}/logs/celery.log"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}Config en: ${INSTALL_DIR}/.env (solo root puede leerlo)${NC}"
