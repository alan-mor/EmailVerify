# celery_app.py
# Este archivo es el punto de entrada para el worker Celery.
# Lee .env directamente para configurar broker ANTES de que Flask exista.
# Uso en supervisor: celery -A celery_app worker ...

import os
from dotenv import load_dotenv

# Cargar .env PRIMERO, antes de cualquier otro import del proyecto
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

from celery import Celery

REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')

celery_app = Celery(
    'emailverifier',
    broker=REDIS_URL,
    backend=REDIS_URL,
    include=['tasks'],  # Importar tasks.py automáticamente
)

celery_app.conf.update(
    task_serializer='json',
    result_serializer='json',
    accept_content=['json'],
    timezone='America/Merida',
    enable_utc=False,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    broker_connection_retry_on_startup=True,
)

# Importar la Flask app para que el worker tenga contexto de DB
from app import create_app as _create_flask_app

_flask_app = _create_flask_app()

class ContextTask(celery_app.Task):
    """Cada tarea corre dentro del contexto Flask (acceso a DB)."""
    abstract = True
    def __call__(self, *args, **kwargs):
        with _flask_app.app_context():
            return self.run(*args, **kwargs)

celery_app.Task = ContextTask

# Registrar tasks
import tasks  # noqa — activa los decoradores @celery_app.task

if __name__ == '__main__':
    celery_app.start()
