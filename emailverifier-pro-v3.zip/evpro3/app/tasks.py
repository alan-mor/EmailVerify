# tasks.py
# Usa celery_app de celery_app.py — el broker está correctamente configurado.
# NO importa nada de app.py (evita circular import).

import csv
import json
import logging
import os
import smtplib
import time
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List, Set

import pandas as pd
import pytz

logger = logging.getLogger(__name__)
MX_TZ = pytz.timezone('America/Merida')


def now_mx():
    return datetime.now(MX_TZ).replace(tzinfo=None)


# ─── Celery instance viene de celery_app.py ───────────────────
# Se importa aquí — celery_app.py ya cargó .env y Redis antes de llegar aquí
from celery_app import celery_app

# ─── DB y modelos vienen de app.py (Flask app context) ────────
# El ContextTask en celery_app.py garantiza que db funcione dentro de la tarea
from app import db
from models import (AppConfig, BlacklistDomain, BlacklistEmail,
                    EmailResult, VerificationJob)
from verifier import verify_email


# ──────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────

def get_blacklists(user_id: int):
    email_bl: Set[str] = set(
        r.email.lower().strip()
        for r in BlacklistEmail.query.filter(
            (BlacklistEmail.user_id == user_id) |
            (BlacklistEmail.user_id.is_(None))
        ).all()
    )
    domain_bl: Set[str] = set(
        r.domain.lower().strip()
        for r in BlacklistDomain.query.filter(
            (BlacklistDomain.user_id == user_id) |
            (BlacklistDomain.user_id.is_(None))
        ).all()
    )
    return email_bl, domain_bl


def parse_email_file(filepath: str) -> List[str]:
    ext = os.path.splitext(filepath)[1].lower()
    emails: List[str] = []

    if ext == '.txt':
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                for part in line.strip().split(','):
                    p = part.strip().strip('"').strip("'").lower()
                    if '@' in p and '.' in p and len(p) >= 6:
                        emails.append(p)
    elif ext == '.csv':
        for enc in ('utf-8', 'latin-1', 'cp1252'):
            try:
                df = pd.read_csv(filepath, header=None, dtype=str,
                                 encoding=enc, on_bad_lines='skip')
                for col in df.columns:
                    for val in df[col].dropna().astype(str):
                        v = val.strip().lower()
                        if '@' in v and '.' in v:
                            emails.append(v)
                break
            except Exception:
                continue
    elif ext in ('.xlsx', '.xls'):
        try:
            df = pd.read_excel(filepath, header=None, dtype=str)
            for col in df.columns:
                for val in df[col].dropna().astype(str):
                    v = val.strip().lower()
                    if '@' in v and '.' in v:
                        emails.append(v)
        except Exception as e:
            logger.error(f'Error leyendo Excel: {e}')
    return emails


def deduplicate(emails: List[str]):
    seen, unique, dupes = set(), [], 0
    for e in emails:
        n = e.strip().lower()
        if n and n not in seen:
            seen.add(n)
            unique.append(n)
        elif n:
            dupes += 1
    return unique, dupes


def save_results_csv(job, results_folder: str) -> str:
    filename = f'job_{job.id}_{int(time.time())}.csv'
    filepath = os.path.join(results_folder, filename)
    os.makedirs(results_folder, exist_ok=True)
    results = EmailResult.query.filter_by(job_id=job.id).all()
    with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['Email','Estado','Score','Razón','Sintaxis OK','Rol/Spamtrap',
                    'Desechable','Freemail','Parqueado','Antispam','DNS/MX OK',
                    'MX Records','Respuesta SMTP','Verificado (CST México)'])
        for r in results:
            w.writerow([
                r.email, r.status, r.score, r.reason or '',
                'Sí' if r.syntax_valid else 'No',
                'Sí' if r.is_role else 'No',
                'Sí' if r.is_disposable else 'No',
                'Sí' if r.is_freemail else 'No',
                'Sí' if r.is_parked else 'No',
                'Sí' if r.is_antispam else 'No',
                'Sí' if r.dns_valid else 'No',
                r.mx_records or '',
                r.smtp_response or '',
                r.checked_at.strftime('%Y-%m-%d %H:%M:%S') if r.checked_at else '',
            ])
    return filename


def send_completion_email(job):
    if not job.notify_email:
        return
    host = AppConfig.get('smtp_host', '')
    port = int(AppConfig.get('smtp_port', '587') or '587')
    user = AppConfig.get('smtp_user', '')
    pwd  = AppConfig.get('smtp_pass', '')
    frm  = AppConfig.get('smtp_from', '') or user
    ssl  = AppConfig.get('smtp_ssl', 'tls')
    if not host or not user:
        return
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f'✅ Verificación completada: {job.name}'
        msg['From'] = frm
        msg['To']   = job.notify_email
        html = f"""<html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
        <div style="background:#1e40af;color:white;padding:20px;border-radius:8px 8px 0 0">
          <h2 style="margin:0">✅ Verificación completada: {job.name}</h2>
        </div>
        <div style="border:1px solid #e2e8f0;padding:20px;border-radius:0 0 8px 8px">
          <table style="width:100%;border-collapse:collapse">
            <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0"><b>Total</b></td><td style="padding:8px">{job.total_emails}</td></tr>
            <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;color:#16a34a"><b>✅ Válidos</b></td><td style="padding:8px;color:#16a34a"><b>{job.valid_count}</b></td></tr>
            <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;color:#d97706"><b>⚠️ Riesgosos</b></td><td style="padding:8px">{job.risky_count}</td></tr>
            <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;color:#dc2626"><b>❌ Inválidos</b></td><td style="padding:8px">{job.invalid_count}</td></tr>
            <tr><td style="padding:8px"><b>🔁 Duplicados</b></td><td style="padding:8px">{job.duplicate_count}</td></tr>
          </table>
        </div></body></html>"""
        msg.attach(MIMEText(html, 'html'))
        if ssl == 'ssl':
            s = smtplib.SMTP_SSL(host, port, timeout=30)
        else:
            s = smtplib.SMTP(host, port, timeout=30)
            if ssl == 'tls':
                s.starttls()
        if user and pwd:
            s.login(user, pwd)
        s.sendmail(frm, [job.notify_email], msg.as_string())
        s.quit()
    except Exception as e:
        logger.error(f'Error notificación: {e}')


# ──────────────────────────────────────────────
# TAREA PRINCIPAL
# ──────────────────────────────────────────────

@celery_app.task(bind=True, name='tasks.run_verification', base=celery_app.Task)
def run_verification(self, job_id: int):
    """Verificación completa en background. Persiste aunque el usuario cierre el navegador."""

    results_folder = os.getenv('RESULTS_FOLDER', '/opt/emailverifier/results')
    enable_smtp  = (AppConfig.get('enable_smtp_verify', 'true') or 'true').lower() == 'true'
    dns_retries  = int(AppConfig.get('dns_retries', '3') or '3')
    smtp_timeout = int(AppConfig.get('smtp_timeout', '10') or '10')

    job = VerificationJob.query.get(job_id)
    if not job:
        logger.error(f'Job {job_id} no encontrado')
        return {'error': f'Job {job_id} no encontrado'}

    try:
        job.status = 'running'
        job.started_at = now_mx()
        job.add_log('🚀 Worker recibió la tarea — iniciando...')
        db.session.commit()

        # ── Leer archivo ──────────────────────────────────────
        job.add_log(f'📂 Leyendo: {os.path.basename(job.input_file)}')
        db.session.commit()

        if not os.path.exists(job.input_file):
            raise FileNotFoundError(f'Archivo no encontrado: {job.input_file}')

        raw = parse_email_file(job.input_file)
        job.add_log(f'📧 {len(raw)} emails encontrados')
        db.session.commit()

        if not raw:
            raise ValueError('El archivo no contiene emails válidos')

        # ── Deduplicar ────────────────────────────────────────
        unique, dupe_count = deduplicate(raw)
        job.duplicate_count = dupe_count
        job.total_emails    = len(unique) + dupe_count
        job.add_log(f'🔄 {dupe_count} duplicados eliminados → {len(unique)} únicos')
        db.session.commit()

        # Guardar duplicados como resultados
        if dupe_count > 0:
            seen_set: Set[str] = set()
            for e in [x.strip().lower() for x in raw if x.strip()]:
                if e in seen_set:
                    db.session.add(EmailResult(
                        job_id=job_id, email=e, status='duplicate',
                        reason='Email duplicado en la lista',
                        syntax_valid=True, score=0, checked_at=now_mx()
                    ))
                else:
                    seen_set.add(e)
            db.session.commit()

        # ── Blacklists ────────────────────────────────────────
        email_bl, domain_bl = get_blacklists(job.user_id)
        job.add_log(f'⛔ Blacklists: {len(email_bl)} emails, {len(domain_bl)} dominios')
        db.session.commit()

        valid_c = invalid_c = risky_c = spam_c = bl_c = 0
        BATCH = 20  # commit cada 20 → progreso visible rápido

        for i, email in enumerate(unique):
            try:
                res = verify_email(
                    email,
                    blacklisted_emails=email_bl,
                    blacklisted_domains=domain_bl,
                    enable_smtp=enable_smtp,
                    dns_retries=dns_retries,
                    smtp_timeout=smtp_timeout,
                )
                s = res['status']
                if   s == 'valid':        valid_c  += 1
                elif s == 'invalid':      invalid_c += 1
                elif s == 'risky':        risky_c   += 1
                elif s == 'spamtrap':     spam_c    += 1
                elif s == 'blacklisted':  bl_c      += 1

                db.session.add(EmailResult(
                    job_id=job_id,
                    email=res['email'],
                    status=s,
                    reason=(res.get('reason') or '')[:500],
                    syntax_valid=res.get('syntax_valid', False),
                    is_role=res.get('is_role', False),
                    is_disposable=res.get('is_disposable', False),
                    is_freemail=res.get('is_freemail', False),
                    is_parked=res.get('is_parked', False),
                    is_antispam=res.get('is_antispam', False),
                    dns_valid=res.get('dns_valid'),
                    mx_records=(', '.join(res.get('mx_records', [])))[:500],
                    smtp_response=(res.get('smtp_response') or '')[:500],
                    score=res.get('score', 0),
                    checked_at=now_mx(),
                ))

            except Exception as ex:
                logger.error(f'Error en {email}: {ex}')
                invalid_c += 1
                db.session.add(EmailResult(
                    job_id=job_id, email=email, status='invalid',
                    reason=f'Error: {str(ex)[:150]}', score=0, checked_at=now_mx()
                ))

            # Commit por lote + actualizar progreso
            if (i + 1) % BATCH == 0 or (i + 1) == len(unique):
                job.processed_emails  = i + 1
                job.valid_count       = valid_c
                job.invalid_count     = invalid_c
                job.risky_count       = risky_c
                job.spamtrap_count    = spam_c
                job.blacklisted_count = bl_c
                pct = round(((i + 1) / len(unique)) * 100, 1)
                job.add_log(
                    f'⚡ {pct}% — '
                    f'✅{valid_c} | ❌{invalid_c} | ⚠️{risky_c} | 🚫{spam_c}'
                )
                db.session.commit()

        # ── Finalizar ─────────────────────────────────────────
        job.status       = 'completed'
        job.completed_at = now_mx()
        job.add_log('💾 Generando CSV...')
        db.session.commit()

        result_file = save_results_csv(job, results_folder)
        job.result_file = result_file
        job.add_log(
            f'✅ ¡Completado! '
            f'Total:{job.total_emails} | ✅{valid_c} | ❌{invalid_c} | '
            f'⚠️{risky_c} | 🔁{dupe_count}'
        )
        db.session.commit()

        send_completion_email(job)
        return {'status': 'completed', 'job_id': job_id}

    except Exception as e:
        logger.error(f'Error fatal job {job_id}: {e}', exc_info=True)
        try:
            job = VerificationJob.query.get(job_id)
            if job:
                job.status = 'failed'
                job.error_message = str(e)[:500]
                job.add_log(f'❌ Error fatal: {str(e)[:200]}')
                db.session.commit()
        except Exception:
            pass
        raise
