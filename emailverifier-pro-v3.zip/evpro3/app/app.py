# app.py
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

db = SQLAlchemy()
login_manager = LoginManager()


def create_app():
    app = Flask(__name__, static_folder='static', template_folder='templates')

    app.config['SECRET_KEY']                  = os.getenv('SECRET_KEY', 'change-me')
    app.config['SQLALCHEMY_DATABASE_URI']     = os.getenv('DATABASE_URL', 'sqlite:///ev.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['MAX_CONTENT_LENGTH']          = 500 * 1024 * 1024
    app.config['UPLOAD_FOLDER']               = os.getenv('UPLOAD_FOLDER', '/opt/emailverifier/uploads')
    app.config['RESULTS_FOLDER']              = os.getenv('RESULTS_FOLDER', '/opt/emailverifier/results')
    app.config['BLACKLIST_FOLDER']            = os.getenv('BLACKLIST_FOLDER', '/opt/emailverifier/blacklists')

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    from routes.auth      import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.verify    import verify_bp
    from routes.admin     import admin_bp
    from routes.api       import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(verify_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(api_bp, url_prefix='/api')

    return app


# Punto de entrada Gunicorn: gunicorn app:app
app = create_app()

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)
