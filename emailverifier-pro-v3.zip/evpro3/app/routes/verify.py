# routes/verify.py
# tasks.run_verification se importa LAZY (dentro de función) — evita circular import
import os, uuid
from datetime import datetime
import pytz
from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_required, current_user
from app import db
from models import VerificationJob, BlacklistEmail, BlacklistDomain

verify_bp = Blueprint('verify', __name__)
MX_TZ = pytz.timezone('America/Merida')
ALLOWED = {'txt', 'csv', 'xlsx', 'xls'}


@verify_bp.route('/verify', methods=['GET', 'POST'])
@login_required
def new_verification():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        notify_email = request.form.get('notify_email', '').strip()
        if not name:
            flash('Escribe un nombre para identificar el trabajo', 'error')
            return redirect(url_for('verify.new_verification'))
        if 'file' not in request.files or request.files['file'].filename == '':
            flash('Selecciona un archivo TXT, CSV o XLSX', 'error')
            return redirect(url_for('verify.new_verification'))
        f = request.files['file']
        ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else ''
        if ext not in ALLOWED:
            flash('Formato no soportado. Usa TXT, CSV o XLSX', 'error')
            return redirect(url_for('verify.new_verification'))
        upload_folder = current_app.config['UPLOAD_FOLDER']
        os.makedirs(upload_folder, exist_ok=True)
        filename = f'{uuid.uuid4().hex}.{ext}'
        filepath = os.path.join(upload_folder, filename)
        f.save(filepath)
        job = VerificationJob(
            user_id=current_user.id,
            name=name,
            status='pending',
            input_file=filepath,
            notify_email=notify_email or None,
            created_at=datetime.now(MX_TZ).replace(tzinfo=None),
        )
        db.session.add(job)
        db.session.commit()
        # LAZY IMPORT — no al nivel del módulo para evitar circular import
        from tasks import run_verification
        task = run_verification.delay(job.id)
        job.celery_task_id = task.id
        job.add_log('⏳ Tarea enviada al worker...')
        db.session.commit()
        flash(f'✅ Verificación "{name}" iniciada. Puedes cerrar el navegador.', 'success')
        return redirect(url_for('dashboard.job_detail', job_id=job.id))
    return render_template('new_verification.html')


@verify_bp.route('/blacklist', methods=['GET', 'POST'])
@login_required
def blacklist():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add_email':
            e = request.form.get('email', '').strip().lower()
            r = request.form.get('reason', '').strip()
            if '@' in e and not BlacklistEmail.query.filter_by(email=e, user_id=current_user.id).first():
                db.session.add(BlacklistEmail(email=e, reason=r, user_id=current_user.id, added_by=current_user.id))
                db.session.commit(); flash(f'{e} agregado', 'success')
        elif action == 'add_domain':
            d = request.form.get('domain', '').strip().lower()
            r = request.form.get('reason', '').strip()
            if '.' in d and not BlacklistDomain.query.filter_by(domain=d, user_id=current_user.id).first():
                db.session.add(BlacklistDomain(domain=d, reason=r, user_id=current_user.id, added_by=current_user.id))
                db.session.commit(); flash(f'{d} agregado', 'success')
        elif action == 'import_file':
            fil = request.files.get('blacklist_file')
            if fil:
                added = 0
                for line in fil.read().decode('utf-8', errors='ignore').splitlines():
                    item = line.strip().lower()
                    if not item: continue
                    if '@' in item:
                        if not BlacklistEmail.query.filter_by(email=item, user_id=current_user.id).first():
                            db.session.add(BlacklistEmail(email=item, user_id=current_user.id, added_by=current_user.id)); added += 1
                    elif '.' in item:
                        if not BlacklistDomain.query.filter_by(domain=item, user_id=current_user.id).first():
                            db.session.add(BlacklistDomain(domain=item, user_id=current_user.id, added_by=current_user.id)); added += 1
                db.session.commit(); flash(f'{added} entradas importadas', 'success')
        elif action == 'delete_email':
            b = BlacklistEmail.query.get(request.form.get('id'))
            if b and (b.user_id == current_user.id or current_user.is_admin):
                db.session.delete(b); db.session.commit()
        elif action == 'delete_domain':
            b = BlacklistDomain.query.get(request.form.get('id'))
            if b and (b.user_id == current_user.id or current_user.is_admin):
                db.session.delete(b); db.session.commit()
        return redirect(url_for('verify.blacklist'))
    return render_template('blacklist.html',
        emails=BlacklistEmail.query.filter_by(user_id=current_user.id).all(),
        domains=BlacklistDomain.query.filter_by(user_id=current_user.id).all())
